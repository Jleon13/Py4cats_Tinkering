""" Convolution of monochromatic spectrum/spectra with Box, Triangle, Gaussian spectral response functions. """

####################################################################################################################################
##########     LICENSE issues:                                                                                            ##########
##########                       This file is part of the Py4CAtS package.                                                ##########
##########                       Copyright 2002 - 2022; Franz Schreier;  DLR-IMF Oberpfaffenhofen                         ##########
##########                       Py4CAtS is distributed under the terms of the GNU General Public License;                ##########
##########                       see the file ../license.txt in the parent directory.                                     ##########
####################################################################################################################################

from string import punctuation
p2s = ''.maketrans(punctuation, len(punctuation)*' ')  # translation table punc-->space

try:                        import numpy as np
except ImportError as msg:  raise SystemExit (str(msg) + '\nimport numeric python failed!')

#fgs13march23 from .. var.euGrid import gridStep, is_uniform
#fgs13march23 from .. var.srf import Gauss, SuperGauss, HyperGauss, UltraGauss, GaussBox, fts
from . euGrid import gridStep, is_uniform
from . srf import Gauss, SuperGauss, HyperGauss, UltraGauss, GaussBox, fts


####################################################################################################################################
##### numpy/scipy convolve vs. 'handmade' multiplication and summation:                                                        #####
#####                                                                                                                          #####
##### numpy.convolve          possibly faster for large arrays                                                                 #####
##### scipy.signal.convolve   automatically chooses fft or the direct method based on an estimation of which is faster.        #####
##### scipy.signal.oaconvolve generally much faster than convolve for large arrays (n > ~500),                                 #####
#####                         and generally much faster than fftconvolve when one array is much larger than the other          #####
#####                                                                                                                          #####
##### BUT:  all these numpy/scipy convolutions return convolved spectrum at monochromatic grid !!!                             #####
#####                                                                                                                          #####
####################################################################################################################################

def _convolveBox (vGrid, yData, hwhm, wGrid):
	""" Convolve spectra with a Box (rectangular) spectral response function.
	    (Input&output see _convolveGauss) """

	# allocate smoothed spectra
	if len(yData.shape)==1:  yBoxed = np.zeros_like(wGrid)
	else:                    yBoxed = np.zeros((len(wGrid),yData.shape[1]))

	deltaV    = (vGrid[-1]-vGrid[0])/(len(vGrid)-1)
	recDeltaV = 1.0/deltaV
	nHalf     = int(hwhm*recDeltaV)
	normFactor = 2*nHalf*deltaV

	# and loop over coarse grid points
	for i,ww in enumerate(wGrid):
		iMid  = int(recDeltaV*(ww-vGrid[0]))  # index of center point in fine grid
		yBoxed[i] = np.trapz (yData[iMid-nHalf:iMid+nHalf+1], dx=deltaV, axis=0)  # not yet normalized!

	return yBoxed/normFactor


####################################################################################################################################

def _convolveTriangle (vGrid, yData, hwhm, wGrid):
	""" Convolve spectra with a triangular spectral response function.
	    (Input&output see _convolveGauss) """

	# setup fine grid for response function
	sGrid = responseGrid(vGrid, hwhm, 2.0)
	# evaluate response function on dense grid with spacing as monochromatic grid
	srf   = (sGrid[-1]-abs(sGrid)) / (2*hwhm)**2

	return integrateProduct (vGrid, wGrid, yData, srf)


####################################################################################################################################

def _convolveGauss (vGrid, yData, hwhm, wGrid, nWidths, gaussType=''):
	""" Convolve spectra with a (generalized) Gaussian spectral response function.

	INPUT:
	vGrid      high resolution wavenumber grid
	yData      monochromatic (high resolution) spectrum/spectra defined at vGrid
	hwhm       half width at half maximum
	wGrid      low resolution wavenumber grid
	nWidths    number of half widths in wings to consider for convolution
	gaussType  default standard Gauss with power 2 in exponent
	           super = power 4; hyper = power 6; ultra = power 8

	OUTPUT:
	yConvolved  low resolution spectrum/spectra
	"""

	# setup fine grid for response function
	sGrid = responseGrid(vGrid, hwhm, nWidths)
	# evaluate response function on dense grid with spacing as monochromatic grid
	if   gaussType.lower()=='super' or gaussType=='4':  srf = SuperGauss(sGrid, hwhm)
	elif gaussType.lower()=='hyper' or gaussType=='6':  srf = HyperGauss(sGrid, hwhm)
	elif gaussType.lower()=='ultra' or gaussType=='8':  srf = UltraGauss(sGrid, hwhm)
	else:                                               srf =      Gauss(sGrid, hwhm)

	return integrateProduct (vGrid, wGrid, yData, srf)


####################################################################################################################################

def _convolveHySpex (vGrid, yData, beta, gamma, wGrid, nWidths):
	""" Convolve spectra with a Gaussian*Box spectral response function.
	    (Input&output see _convolveGauss) """

	# setup fine grid for response function
	sGrid = responseGrid(vGrid, beta+gamma, nWidths)
	# evaluate response function on dense grid with spacing as monochromatic grid
	srf   = GaussBox(sGrid, beta, gamma)

	return integrateProduct (vGrid, wGrid, yData, srf)


####################################################################################################################################

def _convolveFTS (vGrid, yData, mopd, wGrid, nWidths, apo, shift=0.0, sigma=1.0):
	""" Convolve spectra with a FTS instrument lineshape function.

	    mopd     maximum optical path difference
	    apo      apodization
	    shift    wavenumber shift (default 0.0)
	    sigma    damping for Gauss apodization (default 1.0)
	    (further input&output see _convolveGauss) """

	print ('convolvefts', mopd, apo, shift, sigma)
	# setup fine grid for response function
	sGrid = responseGrid(vGrid, 0.5/mopd, nWidths)  # hwhm=0.5/mopd approximation!
	# evaluate response function on dense grid with spacing as monochromatic grid
	if apo:  srf   = fts(sGrid, mopd, apo, shift, sigma)
	else:    srf   = fts(sGrid, mopd)

	return integrateProduct (vGrid, wGrid, yData, srf)


####################################################################################################################################

def responseGrid (vGrid, width, nWidths):
	""" Setup dense grid for response function with spacing as monochromatic grid. """
	deltaV = gridStep(vGrid)

	nSide = int(nWidths*width/deltaV)
	rGrid = vGrid[:nSide+1]-vGrid[0]                       # right side grid
	sGrid = np.concatenate((-np.flipud(rGrid[1:]),rGrid))  # symmetrically to center at 0

	return sGrid


def integrateProduct(vGrid, wGrid, yData, srData):
	""" Allocate array for convolved spectrum/spectra (y) and evaluate convolution product of yData with response data. """

	# allocate smoothed spectra
	if len(yData.shape)==1:  yConvolved = np.zeros_like(wGrid)
	else:                    yConvolved = np.zeros((len(wGrid),yData.shape[1]))

	deltaV    = (vGrid[-1]-vGrid[0])/(len(vGrid)-1)
	recDeltaV = 1.0/deltaV
	nRight = len(srData)//2

	# and loop over coarse grid points
	for i,ww in enumerate(wGrid):
		iMid  = int(recDeltaV*(ww-vGrid[0]))  # index of center point in fine grid
		# multiply monochromatic spectrum with response function and integrate
		if iMid-nRight<0 or iMid+nRight+1>len(vGrid):
			print ("WARNING:", i, ww, iMid, vGrid[iMid], iMid-nRight, iMid+nRight+1)
		yConvolved[i] = np.trapz ((yData[iMid-nRight:iMid+nRight+1].T*srData).T, dx=deltaV, axis=0)

	return yConvolved


####################################################################################################################################

def convolveFunction (vGrid, yValues, value=1.0, srFunction='Gauss', wGrid=None, wUniform=False, sample=None, nWidths=None):

	""" Convolve spectra with an analytical spectral response function (default Gauss).

	    ARGUMENTS:
	    ----------
	    vGrid:      the wavenumber grid of the monochromatic (high resolution) spectra
	    yValues:    a rank-1 spectrum or rank-2 array (matrix) of spectra
	    value:      the value(s) characterizing the response function: half width or modp
	                * Gauss etc, Triangle, Box:  hwhm = half width @ half maximum (wavenumber unit 1/cm)
			* GaussBox:                  (gamma, beta) =  tuple/list of hwhm for Gauss and Box
	                * FTS Fourier transform:     mopd =  maximum optical path difference (unit cm)
			                             optional second float:  wavenumber shift (default 0.0)
						     optional third  float:  Gauss apodization parameter (default 1.0)
			If a second (and third) parameter is required, put all parameters into a list!
	    srFunction: spectral response function (default Gauss)
	    wGrid:      new wavenumber grid (default None ==> set automatically;  when given, do NOT return it again)
	    wUniform:   flag to enforce an equidistant, uniform wGrid, default False
	                wUniform=True when convolveFunction is called as a class method with an odArray, wfArray, or riArray
			(these subclassed arrays do not save the wavenumber grid, just the grid start and end)
	    sample:     number of new grid points per hwhm (default 4.0 except for Box: 1 and Triangle: 2)
	    nWidths:    left and right wing cutoff for Gauss or FTS response function in units of HWHM
	                (default 5.0 for Gauss, 1 for box, 2 for triangle, 25 for unapodized FTS)

	    RETURNS:
	    --------
	    wGrid:      new wavenumber grid  (only if not given as input, i.e. set automatically!)
	    ySmoothed:  the spectrum/spectra convolved with a Gaussian etc. with len(wGrid) spectral points.

	    NOTE:
	    -----
	    * In case of transmission, the convolution has to be called with absorption = 1-transmission
	    * Optical depth should be transformed to absorption = 1 - transmission = 1-exp(-od)
	      before the convolution and transformed back afterwards
	    * In old implementations of convolveGauss, convolveTriangle, convolveBox
	      this transformation was triggered by an extra optional argument what='i'|'t'|'o';
	      In this new implementation the transformation is done in the odArray.convolve method.
	    """

	# check model and wing extension
	srFunc = srFunction.lower()
	if 'box' in srFunc and 'gauss' in srFunc:
		model = 'GaussBox'
		gamma, beta = value
		hwhm        = beta+gamma    # approximation?
		nWidthsDefault = 5.0
	elif 'ft' in srFunc:
		model, apo = 'FTS', srFunction.replace('fts','').translate(p2s).strip();  print (model, apo)
		if   isinstance(value, (int, float)):
			mopd, extra = value, []
		elif isinstance(value,(list,tuple,np.ndarray)) and all([isinstance(vv, (int,float)) for vv in value]):
			mopd, extra = value[0], value[1:]
		else:
			raise ValueError ("convolveFunction -- FTS: expected one to three float(s)")
		hwhm = 0.5/mopd
		if apo:  nWidthsDefault=10.0
		else:    nWidthsDefault=25.0
	elif   srFunc.startswith('g') or 'gauss' in srFunc:  # conflict with FTS-Gauss-apodization
		if   'super' in srFunc:  model, hwhm, nWidthsDefault = 'superGauss', value, 4.0
		elif 'hyper' in srFunc:  model, hwhm, nWidthsDefault = 'hyperGauss', value, 3.0
		elif 'ultra' in srFunc:  model, hwhm, nWidthsDefault = 'ultraGauss', value, 2.0
		else:                                model, hwhm, nWidthsDefault =      'Gauss', value, 5.0
	elif srFunc.startswith('t'):
		model, hwhm, nWidthsDefault = 'Triangle', value, 2.0
	elif srFunc.startswith('b'):
		model, hwhm, nWidthsDefault = 'Box',      value, 1.0
	else:
		raise  ValueError ('convolveFunction --- unknown/invalid spectral response function')

	# check wing extension
	if not nWidths:
		nWidths=nWidthsDefault
	elif isinstance(nWidths, (int, float)) and nWidths>0.0:
		if model in ['Box', 'Triangle'] and not nWidths==nWidthsDefault:
			nWidths=nWidthsDefault;  print ("WARNING - convolve_function: nWidths reset to %f" % nWidths)
		else:
			if nWidths<2.0:  print ("WARNING - convolve_function: nWidths %f very small for %s" % (nWidths, model))
	else:
		raise ValueError ('convolveFunction:  nWidths (wing extension in units of hwhm) invalid or non-positive!')

	# check sampling rate
	if not sample:
		if   model=='Box':       sample=1.0
		elif model=='Triangle':  sample=2.0
		else:                    sample=4.0
	elif isinstance(sample, (int, float)) and sample>=1.0:
		pass
	else:
		raise ValueError ('convolveFunction:  sample (grid point spacing in units of hwhm) invalid or small!')

	# half width (or mopd) positive and not too big?
	if not (isinstance(hwhm, (int,float)) and hwhm>0.0):
		raise ValueError ('convolveFunction:  hwhm is not a positive float!')
	if vGrid[-1]-vGrid[0]<2*nWidths*hwhm:
		raise ValueError ("convolveFunction:  hwhm %f too large compared to wavenumber range %f -- %f" %
		                  (hwhm, vGrid[0], vGrid[-1]))

	# check or set new wavenumber grid
	if   isinstance(wGrid, (int,float)):  # return convolved spectrum for a single wavenumber
		if not vGrid[0]+nWidths*hwhm<wGrid<vGrid[-1]-nWidths*hwhm:
			raise ValueError ("convolveFunction:  new wavenumber point outside vGrid")
		wGrid=np.array(float(wGrid))
		sample=0
	elif isinstance(wGrid, (np.ndarray, list,tuple)):
		if isinstance(wGrid,(list,tuple)):  wGrid = np.array(wGrid)
		if not is_uniform(wGrid) and wUniform:
			raise ValueError ("convolveFunction:  the given wavenumber grid is not uniform/equidistant!")
		if not vGrid[0]+nWidths*hwhm<min(wGrid)<vGrid[-1]-nWidths*hwhm \
		   and vGrid[0]+nWidths*hwhm<max(wGrid)<vGrid[-1]-nWidths*hwhm:
			raise ValueError ("convolveFunction:  new wavenumber points outside vGrid")
		sample=0
	else:
		if sample<=0.0:  raise ValueError ("convolveFunction:  sample non-positive!")
		wLow   = vGrid[0] +nWidths*hwhm+0.5*hwhm  # slightly shrink for security
		wHigh  = vGrid[-1]-nWidths*hwhm-0.5*hwhm
		deltaW = hwhm/sample
		wGrid  = np.linspace(wLow, wHigh, int((wHigh-wLow)/deltaW)+1)

	if len(yValues.shape)>2:
		raise ValueError ('convolveFunction:  unknown shape/type of spectral data,\n',
		                  '                   need rank 1 (spectrum) or rank 2 array (spectra)')

	if   model.endswith('Gauss'):  ySmoothed = _convolveGauss    (vGrid, yValues, hwhm,        wGrid, nWidths, model[:5])
	elif model=='GaussBox':        ySmoothed = _convolveHySpex   (vGrid, yValues, beta, gamma, wGrid, nWidths)
	elif model=='FTS':             ySmoothed = _convolveFTS      (vGrid, yValues, mopd,        wGrid, nWidths, apo, *extra)
	elif model=='Box':             ySmoothed = _convolveBox      (vGrid, yValues, hwhm,        wGrid)
	elif model=='Triangle':        ySmoothed = _convolveTriangle (vGrid, yValues, hwhm,        wGrid)
	else:                          raise ValueError ('invalid response function')

	if sample>0:  return wGrid, ySmoothed
	else:         return        ySmoothed
