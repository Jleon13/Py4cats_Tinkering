"""
Humlicek's rational approximations for the complex error/probability function:
w4    -- Optimized computation of the Voigt and complex probability function (JQSRT 1982).
cpf12 -- An efficient method for evaluation of the complex probability function: the Voigt function and its derivatives (JQSRT 1979)
"""

from math import pi, sqrt
recPi     = 1./pi
recSqrtPi = 1./sqrt(pi)
iRecSqrtPi = 1j*recSqrtPi

try:                        import numpy as np
except ImportError as msg:  raise SystemExit (str(msg) + '\nhumlicek.py:  import numpy failed!')

# select the functions to be imported  (thus 'from humlicek import *' will not import the constants!)
__all__ = 'humlicek1 humlicek2 humlicek3 humlicek4 humlicek  cpf12  zpf14p zpf16p zpf18p zpf20p  cpfX hum1zpf20w'.split()

####################################################################################################################################
#####                           Humlicek (1982) rational approximation                                                         #####
####################################################################################################################################

def humlicek1 (z):
	""" Humlicek (1982) rational approximation:  region I. """
	#t = z.imag-1j*z.real;   w = t * recSqrtPi / (0.5 + t*t)
	w = 1j*recSqrtPi *z / (z*z-0.5)
	return w

def humlicek2 (z):
	""" Humlicek (1982) rational approximation:  region II. """
	# this implementation corresponds to the fortran code
	x, y = z.real, z.imag
	t = y-1j*x
	u = t*t
	w = (t * (1.410474 + u*recSqrtPi))/ (.75 + (u *(3.+u)))
	return w

def Humlicek2 (z):
	""" Humlicek (1982) rational approximation:  region II. """
	# this implementation corresponds to Eq. (12) of the manuscript
	zz = z*z
	w = 1j* (z * (zz*recSqrtPi-1.410474))/ (0.75 + zz*(zz-3.0))
	return w

def humlicek3 (z):
	""" Humlicek (1982) rational approximation:  region III. """
	x, y = z.real, z.imag
	t = y-1j*x
	w =  (16.4955 + t * (20.20933 + t * (11.96482 + t * (3.778987 + 0.5642236*t)))) \
	     / (16.4955 + t * (38.82363 + t * (39.27121 + t * (21.69274 + t * (6.699398 + t)))))
	return w

def humlicek4 (z):
	""" Humlicek (1982) rational approximation:  region IV. """
	x, y = z.real, z.imag
	t = y-1j*x
	u = t*t
	nom = t*(36183.31-u*(3321.99-u*(1540.787-u*(219.031-u*(35.7668-u*(1.320522-u*.56419))))))
	den = 32066.6-u*(24322.8-u*(9022.23-u*(2186.18-u*(364.219-u*(61.5704-u*(1.84144-u))))))
	w  = np.exp(u) - nom/den
	return w


def _humlicek_(z):
	""" Humlicek (1982) complex probability function:  w4 rational approximations.
	    Scalar version;  use humlicek for arrays. """
	s = abs(z.real) + z.imag
	if s>15.0:
		w = humlicek1(z)
	elif s>5.5:
		w = humlicek2(z)
	else:
		if z.imag>=0.195*abs(z.real)-0.176:  w = humlicek3(z)
		else:                                w = humlicek4(z)
	return w


# define a vectorized function
humlicek = np.vectorize(_humlicek_)


####################################################################################################################################
#####                           Humlicek (1979) rational approximation with n=12 and delta=1.5                                 #####
####################################################################################################################################

cr=1.5; crr=2.25  #  y0 and y0**2 of the original
ct = np.array([0., .3142403762544,  .9477883912402, 1.5976826351526, 2.2795070805011, 3.0206370251209, 3.88972489786978])
ca = np.array([0., -1.393236997981977,    -0.2311524061886763,   +0.1553514656420944,
                   -0.006218366236965554, -9.190829861057117e-5, +6.275259577e-7])
cb = np.array([0.,  1.011728045548831,    -0.7519714696746353, 0.01255772699323164,
                    0.01002200814515897, -2.420681348155727e-4,  5.008480613664576e-7])

def cpf12a (z):
	""" Humlicek (1979) complex probability function:  rational approximation for y>0.85 OR |x|<18.1*y+1.65. """
	x, y = z.real, z.imag
	ry = cr+y
	ryry = ry**2
	wk =  (ca[1]*(x-ct[1]) + cb[1]*ry) / ((x-ct[1])**2 + ryry) - (ca[1]*(x+ct[1]) - cb[1]*ry) / ((x+ct[1])**2 + ryry) \
	    + (ca[2]*(x-ct[2]) + cb[2]*ry) / ((x-ct[2])**2 + ryry) - (ca[2]*(x+ct[2]) - cb[2]*ry) / ((x+ct[2])**2 + ryry) \
	    + (ca[3]*(x-ct[3]) + cb[3]*ry) / ((x-ct[3])**2 + ryry) - (ca[3]*(x+ct[3]) - cb[3]*ry) / ((x+ct[3])**2 + ryry) \
	    + (ca[4]*(x-ct[4]) + cb[4]*ry) / ((x-ct[4])**2 + ryry) - (ca[4]*(x+ct[4]) - cb[4]*ry) / ((x+ct[4])**2 + ryry) \
	    + (ca[5]*(x-ct[5]) + cb[5]*ry) / ((x-ct[5])**2 + ryry) - (ca[5]*(x+ct[5]) - cb[5]*ry) / ((x+ct[5])**2 + ryry) \
	    + (ca[6]*(x-ct[6]) + cb[6]*ry) / ((x-ct[6])**2 + ryry) - (ca[6]*(x+ct[6]) - cb[6]*ry) / ((x+ct[6])**2 + ryry)
	wl =  (cb[1]*(x-ct[1]) - ca[1]*ry) / ((x-ct[1])**2 + ryry) + (cb[1]*(x+ct[1]) + ca[1]*ry) / ((x+ct[1])**2 + ryry) \
	    + (cb[2]*(x-ct[2]) - ca[2]*ry) / ((x-ct[2])**2 + ryry) + (cb[2]*(x+ct[2]) + ca[2]*ry) / ((x+ct[2])**2 + ryry) \
	    + (cb[3]*(x-ct[3]) - ca[3]*ry) / ((x-ct[3])**2 + ryry) + (cb[3]*(x+ct[3]) + ca[3]*ry) / ((x+ct[3])**2 + ryry) \
	    + (cb[4]*(x-ct[4]) - ca[4]*ry) / ((x-ct[4])**2 + ryry) + (cb[4]*(x+ct[4]) + ca[4]*ry) / ((x+ct[4])**2 + ryry) \
	    + (cb[5]*(x-ct[5]) - ca[5]*ry) / ((x-ct[5])**2 + ryry) + (cb[5]*(x+ct[5]) + ca[5]*ry) / ((x+ct[5])**2 + ryry) \
	    + (cb[6]*(x-ct[6]) - ca[6]*ry) / ((x-ct[6])**2 + ryry) + (cb[6]*(x+ct[6]) + ca[6]*ry) / ((x+ct[6])**2 + ryry)
	return wk+1j*wl   # wk, wl

def cpf12b (z):
	""" Humlicek (1979) complex probability function:  rational approximation for y<0.85 AND |x|>18.1*y+1.65. """
	x, y = z.real, z.imag
	ry   = cr+y      # yy0   = y+1.5
	y2r  = y +2.*cr  # y2y0  = y+3.0
	rry  = cr*ry     # y0yy0 = 1.5*(y+1.5)
	ryry = ry**2     # yy0sq = (y+1.5)**2
	wk =  ( cb[1]*((x-ct[1])**2-rry) - ca[1]*(x-ct[1])*y2r ) / (((x-ct[1])**2+crr)*((x-ct[1])**2+ryry)) \
            + ( cb[1]*((x+ct[1])**2-rry) + ca[1]*(x+ct[1])*y2r ) / (((x+ct[1])**2+crr)*((x+ct[1])**2+ryry)) \
	    + ( cb[2]*((x-ct[2])**2-rry) - ca[2]*(x-ct[2])*y2r ) / (((x-ct[2])**2+crr)*((x-ct[2])**2+ryry)) \
            + ( cb[2]*((x+ct[2])**2-rry) + ca[2]*(x+ct[2])*y2r ) / (((x+ct[2])**2+crr)*((x+ct[2])**2+ryry)) \
	    + ( cb[3]*((x-ct[3])**2-rry) - ca[3]*(x-ct[3])*y2r ) / (((x-ct[3])**2+crr)*((x-ct[3])**2+ryry)) \
            + ( cb[3]*((x+ct[3])**2-rry) + ca[3]*(x+ct[3])*y2r ) / (((x+ct[3])**2+crr)*((x+ct[3])**2+ryry)) \
	    + ( cb[4]*((x-ct[4])**2-rry) - ca[4]*(x-ct[4])*y2r ) / (((x-ct[4])**2+crr)*((x-ct[4])**2+ryry)) \
            + ( cb[4]*((x+ct[4])**2-rry) + ca[4]*(x+ct[4])*y2r ) / (((x+ct[4])**2+crr)*((x+ct[4])**2+ryry)) \
	    + ( cb[5]*((x-ct[5])**2-rry) - ca[5]*(x-ct[5])*y2r ) / (((x-ct[5])**2+crr)*((x-ct[5])**2+ryry)) \
            + ( cb[5]*((x+ct[5])**2-rry) + ca[5]*(x+ct[5])*y2r ) / (((x+ct[5])**2+crr)*((x+ct[5])**2+ryry)) \
	    + ( cb[6]*((x-ct[6])**2-rry) - ca[6]*(x-ct[6])*y2r ) / (((x-ct[6])**2+crr)*((x-ct[6])**2+ryry)) \
            + ( cb[6]*((x+ct[6])**2-rry) + ca[6]*(x+ct[6])*y2r ) / (((x+ct[6])**2+crr)*((x+ct[6])**2+ryry))
	wl =  (cb[1]*(x-ct[1]) - ca[1]*ry) / ((x-ct[1])**2 + ryry) + (cb[1]*(x+ct[1]) + ca[1]*ry) / ((x+ct[1])**2 + ryry) \
	    + (cb[2]*(x-ct[2]) - ca[2]*ry) / ((x-ct[2])**2 + ryry) + (cb[2]*(x+ct[2]) + ca[2]*ry) / ((x+ct[2])**2 + ryry) \
	    + (cb[3]*(x-ct[3]) - ca[3]*ry) / ((x-ct[3])**2 + ryry) + (cb[3]*(x+ct[3]) + ca[3]*ry) / ((x+ct[3])**2 + ryry) \
	    + (cb[4]*(x-ct[4]) - ca[4]*ry) / ((x-ct[4])**2 + ryry) + (cb[4]*(x+ct[4]) + ca[4]*ry) / ((x+ct[4])**2 + ryry) \
	    + (cb[5]*(x-ct[5]) - ca[5]*ry) / ((x-ct[5])**2 + ryry) + (cb[5]*(x+ct[5]) + ca[5]*ry) / ((x+ct[5])**2 + ryry) \
	    + (cb[6]*(x-ct[6]) - ca[6]*ry) / ((x-ct[6])**2 + ryry) + (cb[6]*(x+ct[6]) + ca[6]*ry) / ((x+ct[6])**2 + ryry)
	return np.exp(-x*x)+y*wk+1j*wl   # wk, wl

def cpf12 (z):
	""" Humlicek (1979) complex probability function: a single rational approximation. """
	xMask = abs(z.real)<18.1*z.imag+1.65
	yMask = z.imag>0.85
	mask  = np.logical_or(xMask,yMask)
	return np.where (mask, cpf12a(z), cpf12b(z))


####################################################################################################################################
#####    Generalization of Humlicek's region I rational approximation                                                          #####
####################################################################################################################################

from scipy.special import roots_hermite

def cpfX (z, n=20, delta=1.55, rootsAndWeights=False):
	""" Humlicek (1979) complex probability function:  a rational approximation for all z=x+iy
	    Eq. (6)
	    WARNING:  large errors for small y and n<16
	"""
	if n%2>0:   raise SystemExit ("ERROR --- cpfX:  n is odd")
	else:       nHalf=n//2
	x, y = z.real, z.imag
	roots, weights = roots_hermite(n)
	alfa = -recPi * weights * np.exp(delta**2) * np.sin(2*roots*delta)
	beta =  recPi * weights * np.exp(delta**2) * np.cos(2*roots*delta)
	ry = delta+y
	ryry = ry**2

	wk=0.0;  wl=0.0
	for t,a,b in zip(roots[nHalf:],alfa[nHalf:],beta[nHalf:]):
		wk += (a*(x-t) + b*ry) / ((x-t)**2 + ryry) - (a*(x+t) - b*ry) / ((x+t)**2 + ryry)
		wl += (b*(x-t) - a*ry) / ((x-t)**2 + ryry) + (b*(x+t) + a*ry) / ((x+t)**2 + ryry)
	if rootsAndWeights:  return wk+1j*wl, roots, weights, alfa, beta
	else:                return wk+1j*wl


####################################################################################################################################
#####       Optimized (single fraction) Humlicek region I rational approximation for n=14 and delta=1.15                       #####
####################################################################################################################################

a14  = np.array([ 3550.42514991854,
                 -11984.9870586454j,
                 -14930.0633786305,
                 22063.806248584j,
                 11744.4498879492,
                 -13165.6872846449j,
                 -3537.51288875589,
                 3488.66575238994j,
                 481.137658025802,
                 -443.850910893116j,
                 -29.4060547608934,
                 26.1346719838452j,
                 0.648818021082958,
                 -0.564189583547495j])

b14  = np.array([ 1055.74218750000, 0.0,
                -14780.3906250000, 0.0,
                29560.7812500000, 0.0,
                -19707.1875000000, 0.0,
                5630.62500000000, 0.0,
                -750.750000000000, 0.0,
                45.5000000000000, 0.0,
                -1.00000000000000])

numPoly14 = np.poly1d(np.flipud(a14))
denPoly7e = np.poly1d(np.flipud(b14[::2]))   # only the even coefficients!

def zpf14p (z):
	""" Humlicek (1979) complex probability function for n=16 and delta=1.35.
	    Optimized rational approximation using numpy.poly1d  (applicable for all z).

	    Maximum relative error to wofz in 0<x<25 and 1e-8<y<1e2:  1.1955e-4 and 7.031-5 for K and L
	"""
	Z = z + 1.15j
	return numPoly14(Z)/denPoly7e(Z*Z)


####################################################################################################################################
#####       Optimized (single fraction) Humlicek region I rational approximation for n=16 and delta=1.32                       #####
####################################################################################################################################

a16  = np.array([ 42419.6273662748,
                 -138908.197688555j,
                 -194798.458729922,
                 271275.209198057j,
                 175309.446248027,
                 -180893.372459287j,
                 -63910.5258910822,
                 57079.7252814755j,
                 11346.9623806612,
                 -9379.45359000424j,
                 -1025.95376648900,
                 811.362595998313j,
                 44.8643376297567,
                 -34.5523241514554j,
                 -0.744730250283634,
                 0.564189583547704j])

b16  = np.array([ 7918.06640624999, 0.0,
                 -126689.062500000, 0.0,
                 295607.812500000, 0.0,
                 -236486.250000000, 0.0,
                 84459.3750000000, 0.0,
                 -15015.0000000000, 0.0,
                 1365.00000000000, 0.0,
                 -60.0000000000000, 0.0,
                 1.00000000000000 ])

numPoly16 = np.poly1d(np.flipud(a16))
denPoly8e = np.poly1d(np.flipud(b16[::2]))   # only the even coefficients!

def zpf16p (z):
	""" Humlicek (1979) complex probability function for n=16 and delta=1.32.
	    Optimized rational approximation using numpy.poly1d  (applicable for all z).

	    Maximum relative error to wofz in 0<x<25 and 1e-8<y<1e2 (501*201 grid points):  9.48622e-05 and 4.459e-6 for K and L
	"""
	Z = z + 1.32j
	return numPoly16(Z)/denPoly8e(Z*Z)


####################################################################################################################################
#####       Optimized (single fraction) Humlicek region I rational approximation for n=18 and delta=1.45                       #####
####################################################################################################################################

a18  = np.array([ 528780.531916677,
                 -1742733.22774323j,
                 -2659262.89625160,
                 3634076.07883237j,
                 2686274.66385913,
                 -2663822.3641152j,
                 -1141082.02881090,
                 964381.040452134j,
                 247986.863623820,
                 -191931.617780727j,
                 -29463.8013318731,
                 21662.7225024781j,
                 1913.27205491556,
                 -1363.33832049576j,
                 -63.0756196799731,
                 44.0646169490376j,
                 0.818074896144303,
                 -0.564189583547751j ])

b18  = np.array([ 67303.5644531250, 0.0,
                 -1211464.16015625, 0.0,
                 3230571.09375000, 0.0,
                 -3015199.68750000, 0.0,
                 1292228.43750000, 0.0,
                 -287161.875000000, 0.0,
                 34807.5000000000, 0.0,
                 -2295.00000000000, 0.0,
                 76.5000000000000, 0.0,
                 -1.00000000000000 ])

numPoly18 = np.poly1d(np.flipud(a18))
denPoly9e = np.poly1d(np.flipud(b18[::2]))   # only the even coefficients!

def zpf18p (z):
	""" Humlicek (1979) complex probability function for n=18 and delta=1.45.
	    Optimized rational approximation using numpy.poly1d  (applicable for all z).

	    Maximum relative error to wofz in 0<x<25 and 1e-8<y<1e2 (501*201 grid points):  4.4963e-05 and 3.826e-7 for K and L
	"""
	Z = z + 1.45j
	return numPoly18(Z)/denPoly9e(Z*Z)


####################################################################################################################################
#####       Optimized (single fraction) Humlicek region I rational approximation for n=20 and delta=1.55                       #####
####################################################################################################################################

a20  = np.array([ 6865178.45748210,
                 -23245645.9721532j,
                 -38001788.0887452,
                 52173717.453027j,
                 42653829.0241984,
                 -41722038.6485502j,
                 -20622968.7470258,
                 16947369.8721768j,
                 5276343.42386924,
                 -3929901.89745931j,
                 -772642.850601482,
                 542788.979242903j,
                 66217.6053629981,
                 -44863.6886942157j,
                 -3250.49103915699,
                 2151.70736563978j,
                 83.8661468810933,
                 -54.6713811197365j,
                 -0.874493854499027,
                 0.564189583547758j ])

b20  = np.array([ 639383.862304687, 0.0,
                 -12787677.2460938, 0.0,
                 38363031.7382813, 0.0,
                 -40920567.1875000, 0.0,
                 20460283.5937500, 0.0,
                 -5456075.62500000, 0.0,
                 826678.125000000, 0.0,
                 -72675.0000000000, 0.0,
                 3633.75000000000, 0.0,
                 -95.0000000000000, 0.0,
                 1.0 ])

numPoly20  = np.poly1d(np.flipud(a20))
denPoly10e = np.poly1d(np.flipud(b20[::2]))   # only the even coefficients!

def zpf20p (z):
	""" Humlicek (1979) complex probability function for n=20 and delta=1.55.
	    Optimized rational approximation using numpy.poly1d  (applicable for all z).

	    Maximum relative error to wofz in 0<x<25 and 1e-8<y<1e2 (501*201 grid points):  4.4963e-05 and 4.277e-8 for K and L
	"""
	Z = z + 1.55j
	return numPoly20(Z)/denPoly10e(Z*Z)


####################################################################################################################################
#####  Combinations of optimized Humlicek (1979) rational approximation (n=20, delta=1.55) with his 1982 asymptotic approx.    #####
####################################################################################################################################

def hum1zpf20w (z, s=25.0):
	""" Complex error function w(z)=w(x+iy) combining Humlicek's rational approximations:

	    |x|+y>s:   Humlicek (JQSRT, 1982) rational approximation for region I;
	    else:      Humlicek (JQSRT, 1979) rational approximation with n=20 and delta=y0=1.55

	    Version using np.where, useful for contour plots.
	    
	    Maximum relative error to wofz in 0<x<30 and 1e-8<y<1e3:
            delta K / K = 1.078e-5   (max error for y = 0.7, constant error 6.5e-6 for all y<0.1)
	"""

	return np.where(abs(z.real)+z.imag>s, z * iRecSqrtPi / (z*z-0.5), zpf20p(z))


def hum1zpf20m (x, y, s=25.0):
	""" Complex error function w(z)=w(x+iy) combining Humlicek's rational approximations:

	    |x|+y>s:  Humlicek (JQSRT, 1982) rational approximation for region I;
	    else:     Humlicek (JQSRT, 1979) rational approximation with n=20 and delta=y0=1.55

	    Version using a mask and np.place;  two real arguments x, y (usually an array and a scalar).  """

	# For safety only. Probably slows down everything. Comment it if you always have arrays (or use assertion?).
	# if isinstance(x,(int,float)):  x = np.array([x])
	# x = np.atleast_1d(x)

	t = y-1j*x
	w = t * recSqrtPi / (0.5 + t*t)  # Humlicek (1982) approx 1 for s>15

	if y<s:
		mask  = abs(x)+y<s                      # returns true for interior points
		Z     = x[np.where(mask)]+ 1j*(y+1.55)  # returns small complex array covering only the interior region
		np.place(w, mask, numPoly20(Z)/denPoly10e(Z*Z))
	return w


def hum1zpf16p (z, s=15.0):
	""" Complex error function w(z)=w(x+iy) combining Humlicek's rational approximations:

	    |x|+y>s:  Humlicek (JQSRT, 1982) rational approximation for region I;
	    else:     Humlicek (JQSRT, 1979) rational approximation with n=16 and delta=y0=1.32

	    Version using a mask and np.place;  two real arguments x, y (usually an array and a scalar).  """

	# For safety only. Probably slows down everything. Comment it if you always have arrays (or use assertion?).
	# if isinstance(x,(int,float)):  x = np.array([x])
	# x = np.atleast_1d(x)

	w = z * iRecSqrtPi / (z*z-0.5)                    # Humlicek (1982) approx 1 for s>15

	mask  = abs(z.real)+z.imag<s                      # returns true for interior points
	if mask.any():
		Z     = z[np.where(mask)]+ 1.32j          # returns small complex array covering only the interior region
		np.place(w, mask, numPoly16(Z)/denPoly8e(Z*Z))
	return w


