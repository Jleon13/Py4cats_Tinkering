"""  Estimate Atmospheric Temperature from Thermal Infrared Spectra by Chahine Relaxation. """

import numpy as np

try:
	from matplotlib.pyplot import plot
except ImportError:
	print ('WARNING --- radInt:  matplotlib not available, no quicklook!')


from .. art.radInt import riArray
from .. art.od2ri import dod2ri
from .. art.oDepth import odSum
from .. lbl.lbl2od import lbl2od
from .. art.planck import planck
from .. art.ac2wf import dod2wf
from .. art.wgtFct import wfPeakHeight
from .. var.convolution     import convolveGauss
from .. var.cgsUnits import cgs
from .. var.radiance2Kelvin import radiance2Kelvin
from .. var.misc import runningAverage


####################################################################################################################################

def chahine_guessSelected (radObs, mapVZ, merge=None):
	"""
	Given an IR radiance spectrum and an altitude-wavenumber mapping estimate atmospheric temperature from brightness temp.
	at a few hand-selected wavenumbers.
	"""

	temperatures = np.empty(mapVZ.shape[0])
	vGrid = radObs.grid()  # wavenumber grid
	dv    = (vGrid[-1]-vGrid[0])/(len(vGrid)-1)
	# equ. brightness temperature
	ebt   = radObs.kelvin()

	for j,v in enumerate(mapVZ['v']):
		i = int((v-vGrid[0])/dv)
		i = max(min(i,len(vGrid)-1),0)
		if isinstance(merge,int):  temperatures[j] = np.mean(ebt[i-int(merge/2):i+int(merge/2)])
		else:                      temperatures[j] = ebt[i]

	return  temperatures


####################################################################################################################################

def chahine_guessAll (radObs, wfPeakHeights, zStep=1.0):
	""" Given an IR radiance (intensity) spectrum and a spectrum of weighting function peak heigths
	    estimate atmospheric temperatures from equivalent brightness spectrum.

	    NOTE:  Altitude units (wfPeakHeights, zStep) have to be the same, consistent (i.e. km allowed)
	"""

	# check input spectrum
	if   isinstance(radObs, riArray):
		ebt = radObs.kelvin()
	elif isinstance(radObs, np.ndarray) and min(radObs)>100 and max(radObs)<500:
		ebt = radObs
	else:
		raise ValueError ("chahine_guessAll: radObs neither an riArray nor an equ. brightness temperature spectrum")

	if not len(ebt)==len(wfPeakHeights):
		raise ValueError ("chahine_guessAll: radObs and wfPeakHeights spectra/arrays have different lengths")

	zGrid = np.arange(zStep, max(wfPeakHeights), 2*zStep)
	zT = []
	for z in zGrid:
		mask = abs(wfPeakHeights-z)<zStep
		if sum(mask)>1:
			tEst = ebt[mask].mean()
			zT.append([z,tEst])

	zT = np.array(zT)
	return zT[:,0], zT[:,1]


def chahine_update (radObs, radMod, wfPeakHeights, zOld, tOld):
	""" Given two IR radiance (intensity) spectra (observed and model) and a spectrum of weighting function peak heigths
	    estimate atmospheric temperatures from Chahine's ratio of equivalent brightness temperatures. """

	if not len(radObs)==len(radMod)==len(wfPeakHeights):
		raise ValueError ("chahine_update: radObs, radMod, and wfPeakHeights spectra/arrays have different lengths")

	### NOTE:  these two radiances are the atmospheric contribution only, i.e. surface term should be subtracted !!!

	zStep = min(np.ediff1d(zOld))/2
	zT = []
	for l,z in enumerate(zOld):
		mask = abs(wfPeakHeights-z)<zStep
		if sum(mask)>1:
			wGrid = radObs.grid()[mask]
			ratio = radObs.base/radMod.base
			bbNew = ratio[mask]*planck(wGrid, tOld[l])
			tEst  = np.mean(radiance2Kelvin(wGrid, bbNew))
			zT.append([z,tEst])
	zT = np.array(zT)
	return zT[:,0], zT[:,1]


def chahine_extrapolate (zCoarse, tCoarse, zFine, baseVectors):
	""" "Extrapolate" temperature data (T defined for some z) to a fine altitude grid by fitting to base vectors. """
	# first regrid base vectors to coarse grid
	baseVectorsCoarse = np.array([np.interp(zCoarse, zFine, baseVectors[:,k]) for k in range(baseVectors.shape[1])]).T
	# next estimate expansion coefficients
	xFit  = np.linalg.lstsq(baseVectorsCoarse, tCoarse, rcond=0)[0]
	# finally evaluate temperature on fine, extended grid
	tFine = np.dot(baseVectors, xFit)
	return tFine


### Alternative combination of interpolation & extrapolation:
### Use extrapolation with "simple" base function a+b*z only for BoA and ToA (avoids ueberschwinger?)
### Use interpolation (with interp) for mid atmosphere

def chahine_interpolate (zCoarse, tCoarse, zFine, returnX=False):
	""" EXPERIMENTAL:  Interpolate (2 point) inside, extrapolate with straight line outside. """
	# interpolation inside
	maskIn = np.logical_and(zCoarse.min()<=zFine, zFine<=zCoarse.max())
	if zCoarse[0]<zCoarse[-1]:  tempIn = np.interp(zFine[maskIn], zCoarse, tCoarse)
	else:                       tempIn = np.interp(zFine[maskIn], zCoarse[::-1], tCoarse[::-1])
	# extrapolation outside
	baseVectors = np.c_[np.ones_like(zFine), zFine]
	xFit  = np.linalg.lstsq(baseVectors[maskIn], tempIn, rcond=0)[0]
	tFine = np.dot(baseVectors, xFit)  # a straight line temperature profile everywhere
	# now replace data inside
	tFine[maskIn] = tempIn
	# PROBLEM:  discontinuous profile!!!
	if returnX:  return tFine, xFit
	else:        return tFine


####################################################################################################################################

def chahine_relax_all (radObs, dictLineList, atmModel, baseVectors,
                       zStep_km=1.0, confine=None, updateWF=True, mxDeltaTemp=5.0, mxIter=10, showSteps=0):
	""" Iterative solution using Chahine estimate and extrapolation by linear least squares with a set of base vectors.
	    This version computes weighting function internally using 'a priori' atmosphere (updated during iteration) !!!

	ARGUMENTS:
	----------
	radObs        observed radiance spectrum ("riArray", subclassed numpy array including attributes such as wavenumber limits)
	dictLineList  dictionary of line lists (Hitran or Geisa excerpt returned by higstract)
	atmModel      a structured array with atmospheric data (a "matrix" with named columns for "p", "T", "H2O", ....)
	              !!! including an initial guess temperature profile !!!
	baseVectors   len(zGrid)*len(x) "matrix" (where x is the array of expansion coefficients to be estimated)
	zStep_km      tolerance distance (km)
	confine
	updateWF      recalculate weighting functions and v-z mapping in each iteration (default True)
	mxDeltaTemp   max change of temperature for convergence tests of temperature and equiv. brightness temperature
	mxIter        max number of iteration
	showSteps     when positive: plot init guess and intermediate temperature; when negative: plot init temp only

	RETURNS:
	--------
	atmFinal          structured array of atmospheric data with the final temperature
	tCoarse, zCoarse  numpy array of temperature estimates on coarse grid
	nIter             number of iterations
	deltaT            the last temperature update (numpy array)
	wfPeakHeights     spectrum of weighting function peak heights for the last T profile
	radMod            riArray of final radiance spectrum
	"""

	#from py4cats.art.atmos1D import atmPlot # atmSave
	# init guess temperature
	#atmPlot(atmModel, color='y', ls='-.')
	#atmSave(atmModel, '/tmp/atmModel_0', units=1)

	zGrid_km = cgs('!km', atmModel['z'])     # high vertical resolution altitude grid [km]
	obsAngle = radObs.obsAngle               # viewing angle
	hwhm     = float(radObs.srf.split()[1])  # width of response function

	dodl   = lbl2od(atmModel, dictLineList, radObs.x+5.5*hwhm+5)  # delta optical depth list
	wgtFct = dod2wf(dodl, obsAngle).convolve(hwhm, 'G', wGrid=radObs.grid())  # weighting functions
	wfPeakHeights = cgs('!km', wfPeakHeight(wgtFct))

	if radObs.moreAttr.get('surface'):  radObsAtm = subtract_surface(dodl, radObs)  # instead of using the true surface temp, estimate it!
	else:                               radObsAtm = radObs.copy()

	# first guess temperature
	zCoarse, tCoarse = chahine_guessAll (radObsAtm, wfPeakHeights, zStep_km)
	tFine = chahine_extrapolate(zCoarse, tCoarse, zGrid_km, baseVectors)
	if showSteps:
		plot (tCoarse, zCoarse, 'cx', label='init')
		plot (tFine, zGrid_km, 'c:')

	ebtObs = radObs.kelvin()  # equivalent brightness temperature
	if isinstance(confine, float):
		minEBT, maxEBT = min(ebtObs), max(ebtObs)
		loCut, hiCut = min(confine, 1/confine), max(confine, 1/confine)

	nIter = 0
	while True:
		nIter +=1  # start to iterate
		tOld = tFine.copy()
		atmModel['T'] = tFine
		#atmSave(atmModel, '/tmp/atmModel_%i' % nIter, units=1)
		dodl   = lbl2od (atmModel, dictLineList, radObs.x+5.5*hwhm+5)
		radMod = dod2ri (dodl, obsAngle, atmModel['T'][0]).convolve(hwhm, wGrid=radObs.grid())
		if radObs.moreAttr.get('surface'):
			tod    = odSum(dodl)
			radSurface  = planck(radObs.grid(), atmModel['T'][0]) * tod.convolveAbs(hwhm, wGrid=radObs.grid(), returnTrans=1)
			radObsAtm = radObs - radSurface
			radModAtm = radMod - radSurface

		if updateWF:
			wgtFct        = dod2wf(dodl, 180.0).convolve(hwhm,'G', wGrid=radObs.grid())
			wfPeakHeights = cgs('!km', wfPeakHeight(wgtFct))

		zCoarse, tCoarse = chahine_update (radObsAtm, radModAtm, wfPeakHeights, zCoarse, tCoarse)
		tFine  = chahine_extrapolate(zCoarse, tCoarse, zGrid_km, baseVectors)
		deltaT = abs(tFine-tOld)
		deltaEBT = radObs.kelvin()-radMod.kelvin()

		if showSteps>0 and nIter<8:
			plot (tFine, zGrid_km, 'y', dashes=[2*nIter,1],
			      label='%5.1fK %5.1fK' % (max(abs(deltaT)), max(abs(deltaEBT))))
		if nIter>mxIter or max(abs(deltaT))<mxDeltaTemp or max(abs(deltaEBT))<mxDeltaTemp:  break
		if isinstance(confine,float):
			tFine = np.where(tFine<loCut*minEBT, minEBT, tFine)
			tFine = np.where(tFine>hiCut*maxEBT, maxEBT, tFine)

	atmModel['T'] = tFine
	dodl   = lbl2od (atmModel, dictLineList, radObs.x+5.5*hwhm+5)
	radMod = dod2ri (dodl, obsAngle, atmModel['T'][0]).convolve(hwhm, wGrid=radObs.grid())  # without surface emission

	return atmModel, tCoarse, zCoarse, nIter, deltaT, radMod


####################################################################################################################################

def subtract_surface (dodl, radObs, join=1):
	""" Remove surface thermal emission (attenuated by transmission of intervening atmosphere) from top-of-atmos radiance. """
	tod    = odSum(dodl)
	hwhm = float(radObs.srf.split(':')[1])
	trans  = 1.0-convolveGauss(tod.grid(), 1.0-np.exp(-tod.base), hwhm, radObs.grid())
	if   join>1:  radMax = np.max(runningAverage(radObs.base, join))
	elif join<0:  radMax = planck(radObs.grid(), dodl[0].t.max())      # use BoA temperature
	else:         radMax = np.max(radObs)
	return  radObs - radMax*trans
