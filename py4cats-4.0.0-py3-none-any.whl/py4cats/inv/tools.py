"""
Some  Utility  Routines  for  Earthlike  Exoplanet  Least  Squares  Fits
"""


from glob import glob

try:
	import numpy as np
except ImportError as msg:
	raise SystemExit (str(msg) + '\nimport numpy and scipy failed!')

try:
	from matplotlib.pyplot import subplot, plot, xlabel, ylabel, title
except ImportError as msg: print ("WARNING --- import matplotlib.pyplot failed!\n" + str(msg))

from ..lbl.higstract import higstract
from ..art.atmos1D import atmPlot
from ..art.radInt  import riArray, riPlot
from ..var.aeiou import loadxy
from ..var.pairTypes import Interval


####################################################################################################################################
####################################################################################################################################

def linLstSquares (yData, baseVectors):
	""" Return a linear least squares approximation y(z) = x_l baseVector_l(z) of the data vector. """
	if len(yData.shape)>1:  raise ValueError ("linLstSquares --- expected a one-dim data array!")
	if not len(yData)==baseVectors.shape[0]:  raise ValueError ("linLstSquares: data and base vector shapes inconsistent!")

	xCoeff = np.linalg.lstsq(baseVectors, yData, rcond=None)[0]  # ignore residuals etc. returned
	yFit   = np.dot(baseVectors, xCoeff)
	return yFit


def load_fit_pickled (fitFile):
	""" Open a numpy pickled file with fit results and return a dictionary. """
	with open(fitFile, 'rb') as pf:
		fitDict = np.load(pf, allow_pickle=1)
	return fitDict


def dump_fit_pickled (fitDict, fitFile):
	""" Open a numpy pickled file and save a dictionary with fit result. """
	# NOTE:  pylint reports an error: E0602: Undefined variable 'dump' (undefined-variable)
	# BUT:   Type:      builtin_function_or_method
	with open(fitFile, 'wb') as pf:  dump(fitDict, pf)


def show_zT (ztFiles, atmData, usecols=(0,1)):
        """ Compare altitude vs. temperature 'true reference' vs. fitted. """
        if isinstance(ztFiles,str) and ('*' in ztFiles or '?' in ztFiles):  ztFiles = glob(ztFiles)
        if   len(ztFiles)>12:  nRows, nCols=5,4
        elif len(ztFiles)> 6:  nRows, nCols=4,3
        elif len(ztFiles)> 1:  nRows, nCols=3,2
        else:                  nRows, nCols=1,1
        for j, file in enumerate(ztFiles):
                pp=file[:-4]
                subplot(nRows, nCols, j+1)
                atmPlot(atmData[pp], color='b', marker='x')
                zi,ti = loadxy('%s.zTi' % pp, usecols);      plot(ti,zi, 'y:')
                zf,tf = loadxy('%s.zTf' % pp, usecols);      plot(tf,zf, 'r+--')
                if (j+1)<=nCols*(nRows-1):  xlabel("")
                if (j+1)%nCols!=1:          ylabel("")
                title(pp)


def show_vi (viFiles, radDict):
        """ Compare observed vs.fitted/modeled radiances. """
        if isinstance(viFiles,str) and ('*' in viFiles or '?' in viFiles):  viFiles = glob(viFiles)
        if   len(viFiles)>12:  nRows, nCols=5,4
        elif len(viFiles)> 6:  nRows, nCols=4,3
        elif len(viFiles)> 1:  nRows, nCols=3,2
        else:                  nRows, nCols=1,1
        for i, file in enumerate(viFiles):
                pp=file[:-4]
                subplot(nRows, nCols, i+1)
                riPlot(radDict[pp], color='b', marker='x')
                vf,rf = loadxy('%s.vIf' % pp);      plot(vf,rf, 'r+--')
                if i<=nCols*(nRows-1):  xlabel("")
                if i%nCols!=1:          ylabel("")
                title(pp)

####################################################################################################################################


def get_lines (radObs, higsFile):
	""" Given (a dictionary of) (observed) radiances, get (max) wavenumber interval and half width and extract lines. """
	if   isinstance(radObs, dict):
		wLimits = Interval(min([radObs[pp].x.lower for pp in radObs.keys()]),
				   max([radObs[pp].x.upper for pp in radObs.keys()]))
		hwhm    = max([radObs[pp].moreAttr['srfValue'] for pp in radObs.keys()])
	elif isinstance(radObs, riArray):
		wLimits = radObs.x
		hwhm    = radObs.moreAttr['srfValue']
	else:
		raise TypeError ("get_lines:  expected a riArray or a dictionary thereof!")

	# extract lines from hitran
	dll = higstract(higsFile, wLimits+5*hwhm+10, 'main')

	# remove tiny lines
	if   700.0 in wLimits:
		# TIR2 - CO2 v2 band - longwave Interval(660,750),  hwhm=0.25
		del dll['N2O'];   dll['O3'] = dll['O3'].strong(1e-22);  dll['CO2'] = dll['CO2'].strong(1e-24)
	elif 2400.0 in wLimits:
		# TIR3 - CO2 v3 band - shortwave Interval(2350,2420),  hwhm=1.0 (e.g. IASI)
		del dll['N2O']
	elif 1250.0 in wLimits:
		# TIR - CH4 dyad band Interval(1189,1310),  hwhm=0.5
		del dll['O3'];  dll['N2O'] = dll['N2O'].strong(1e-22)
	elif 3100.0 in wLimits:
		# TIR - CH4 pentad band  Interval(2950,3250),  hwhm=1.0
		pass  #  use all lines
	else:
		raise ValueError ('get_lines:  invalid or unknown band!')

	return dll, wLimits, hwhm
