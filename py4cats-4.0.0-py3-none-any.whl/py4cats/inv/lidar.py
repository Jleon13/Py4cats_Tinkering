#!/usr/bin/env python3

"""  lbl2daod
computation for lidar (line-by-line differential absorption optical depth due to molecular absorption)

from py4cats.xxx.lidar import *

lambdaMerlin = Interval(1645.552, 1645.846)                            # wavelength [nm] interval
mLimits      = lambda2nu(lambdaMerlin, nm=1)                           # wavenumbers [1/cm] interval (6075.9026, 6076.9881)
dllm = higstract('/data/lbl/hitran/2000/lines', mLimits+2.5, 'main')   # dictionary of line lists
mls  = atmRead('/data/atm/20/mls.xy')                                  # midlatitude summer 20 levels

zzz, daod = lbl2daod(mls, dllm, mLimits)
plot(daod, zzz)
"""


_LICENSE_ = """\n
This file is part of the Py4CAtS package.

Authors:
Franz Schreier
DLR-IMF Oberpfaffenhofen
Copyright 2002 - 2024  The Py4CAtS authors

Py4CAtS is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Py4CAtS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

####################################################################################################################################

# import some standard python modules
import os

try:                        import numpy as np
except ImportError as msg:  raise ImportError (str(msg) + '\nimport numpy (numeric python) failed!')

from py4cats.art.atmos1D import isAtmosArray, atmRead, gases
from py4cats.lbl.lines import isLineData
from py4cats.lbl.lbl2od import lbl2od
from py4cats.art.oDepth import dod2cod, flipod
from py4cats.var.cgsUnits import cgs
from py4cats.var.pairTypes import Interval, PairOfFloats
from py4cats.var.moreFun import cosdg


####################################################################################################################################

def lbl2daod (atmos, lineListsDict, xLimits=None, obsAngle=180.0,
	      mtckd=None, cia=None, rayleigh=None, aerosol=None, lineShape="Voigt",
	      sampling=5.0, wingExt=10.0, nGrids=3, gridRatio=8, nWidths=25.0, lagrange=2,
              interpolate=2, xsFile=None, acFile=None, verbose=False):
	"""
	Compute molec. cross sections, abs. coefficient, and layer optical depth and finally difference of cumulative optical depth.
	1. Compute cross sections for some molecule(s) and some pressure(s),temperature(s) by summation of line profiles;
	2. Compute absorption coefficients as product cross section times molecular density, summed over all molecules;
	3. 'Integrate' absorption coefficients along vertical path thru atmosphere to get layer/delta optical depth.
	4. Optionally add MTCKD H2O continuum, CIA (collision induced absorption), aerosol, and/or Rayleigh extinction.
	5. Compute cumulative optical depth and its difference for two wavenumbers (typically near line center and wing).

	ARGUMENTS:
	----------
	atmos:         atmospheric data set, a structured numpy array including zGrid=atmos['z'], pressure=atmos['p'], ...
	               (For convenience the file can be given instead of the numpy array)
	lineListsDict  (molecular) line parameters: a dictionary of structured arrays
        xLimits:       Interval with lower and upper wavenumber [cm-1]
	               !!! the lower and upper limits are interpreted as on and off wavenumbers !!!
	obsAngle:      observation angle [dg] relative to zenith (default 180dg nadir downlooking)
	mtckd:         Mlawer-Tobin-Clough-Kneizys-Davies H2O continuum (version 4 as given by Hitran), default None
	cia:           collision induced absorption, default None;
	               either a single file (Hitran format) or list thereof (* wildcard supported!)
	rayleigh:      Rayleigh extinction, default None;
	               if True, use nicolet model;  other choices: bodhaine, bucholtz, CO2, H2
	               a positive number is interpreted as 'Rayleigh enhancement factor' (with the Nicolet model)
	aerosol:       Aerosol optical depth 8.85e-30*N*v**1.3, default None;
	               a positive number is interpreted as 'Aerosol enhancement factor'
		       a list of two floats is interpreted as factor and Angstroem exponent (default 1.3)

	RETURNS:
	--------
	zGrid_km       altitudes [km]
	daod           diff. absorption optical depths

	See the lbl2xs, lbl2od functions for details about other optional arguments (relevant for numerics etc.).

	See MLN-PLDP-ATBD-90001-PI_v1.2.pdf Eq. (2.26) and (2.71)
	"""

	# check the correct types of the first two mandatory arguments
	if isAtmosArray(atmos):
		print ('\n lbl2daod: ', len(atmos), 'level atmosphere ', gases(atmos))
	elif isinstance(atmos, str) and os.path.isfile(atmos):
		atmos = atmRead(atmos)
	else:
		raise TypeError ("lbl2daod:  incorrect first argument,\n" +
		                 "           expected a structured numpy array of atmospheric data")

	if isLineData(lineListsDict):  print (' lbl2daod:  line data for ', list(lineListsDict.keys()))
	else:                    raise TypeError ("lbl2daod:  incorrect second argument,\n" +
		                                  "           expected a (dictionary of) structured numpy array(s) of line data")

	# compute molecular cross sections, sum over molecules to absorption coefficient, and 'integrate' to layer optical depth
	dodList = lbl2od (atmos, lineListsDict,
	                  xLimits, mtckd, cia, rayleigh, aerosol,
			  lineShape, sampling, wingExt, nGrids, gridRatio, nWidths, lagrange,
			  interpolate, xsFile, acFile, verbose)

	# compute cumulative optical depths and return differences at two wavenumbers
	zGrid_km, daod = dod2daod (dodList, obsAngle)

	return zGrid_km, daod


####################################################################################################################################

def dod2daod (dodList, vPair=None, obsAngle=180.0):
	""" Given a list of delta (layer) optical depths compute the difference of cumulative optical depths at two wavenumbers
	    (typically at/near line center and wing;  if unspecified consider very first and last wavenumber).

	ARGUMENTS:
	----------
	dodList:       delta (layer) optical depths (a list of odArray's)
	vPair:         wavenumber pair (default optical depths interval)
	obsAngle:      observer viewing zenith angle: 0dg=uplooking ... 180dg=downloooking/nadir (default)
	               NOTE:  a horizontal view with 90dg is not implemented!!!
		              uplooking to be implemented

	RETURNS:
	--------
	zGrid_km       altitudes [km]
	daod           differential absorption optical depths

	EXAMPLE:
	--------
	mls     =  atmRead('/data/atm/50/mls.xy')                                # midlatitude summer 50 levels
	mLimits = Interval(6075.902, 6076.988)                                   # wavenumbers [cm-1]
	dll     = higstract('/data/lbl/hitran/2000/lines', mLimits+2.5, 'main')  # dictionary of LineLists
	dodList = lbl2od(mls, dll, mLimits+0.1, sampling=10.)                    # delta optical depth list
	zzz, daod0 = dod2daod(dodList)                                           # v = 6075.802, 6077.088
	zzz, daod1 = dod2daod(dodList, vPair=mLimits)                            # v = 6075.902, 6076.988
	zzz, daod2 = dod2daod(dodList, vPair=mLimits-0.1)                        # v = 6076.002, 6076.888
	"""

	# slant path
	if 90.0<obsAngle<=180.0:
		mue = 1.0/cosdg(180.0-obsAngle)
		dodList = [mue*dod for dod in dodList]
	else:
		raise ValueError ("lidar.lbl2daod:  uplooking not yet implemented")

	# accumulate all delta (layer) optical depths to cumulative optical depths and return a list of odArray's.
	# the first element returned is the top layer optical depth, the second element with the two top layers, ...
	codList = dod2cod (flipod(dodList))

	# extract the altitudes
	zGrid_km  = cgs('!km', np.array([cod.z.right for cod in codList]))

	# ... and compute cumulative optical depth differences
	if isinstance(vPair, (tuple,list)):  vPair = PairOfFloats(*vPair)
	if isinstance(vPair, Interval):      vPair = PairOfFloats(*vPair.limits())
	if isinstance(vPair, PairOfFloats):
		if codList[0].x.lower<=vPair.min() and vPair.max()<=codList[0].x.upper:
			codListX = [np.interp(vPair.list(), cod.grid(), cod.base) for cod in codList]
			daod     =  np.array([abs(cod[0]-cod[-1]) for cod in codListX])
		else:
			raise ValueError ("lidar.lbl2daod:  requested wavenumbers not in opt.depth interval")
	else:
		daod     = np.array([abs(cod[0]-cod[-1]) for cod in codList])

	return zGrid_km, daod
