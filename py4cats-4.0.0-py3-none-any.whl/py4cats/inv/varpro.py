"""
        VARPRO = Variable Projection --- Solve a separable nonlinear least squares problem.

         Given a set of m observations yObs(1), ..., yObs(m)
         this program computes a [weighted] separable least squares fit using the model

          eta(alpha, beta, t)  =  beta_1 * phi_1 (alfa,t) + ...  + beta_nBeta * phi_nBeta (alfa,t)

	 [ToDo: optionally with an extra term  + phi_{nBeta+1} (alpha,t)]

         This program determines optimal values of the nBeta nonlinear parameters
         alpha and the n linear parameters c, given observations y at m
         different values of the "time" t and given evaluation of phi and
         (optionally) derivatives of phi.
"""

####################################################################################################################################
#####                                                                                                                          #####
##### Second version of the translation of the matlab varpro.m                                                                 #####
#####   function [alpha, c, wresid, wresid_norm, y_est, Regression] = varpro(y, w, alpha, n, ada, lb, ub, options)             #####
#####                                                                                                                          #####
##### Dianne P. O'Leary and Bert W. Rust, September 2010      [Comput Optim Appl (2013) 54:579-593]                            #####
#####                                                         http://www.cs.umd.edu/users/oleary/software/                     #####
#####  NOTES --- Differences to / Changes from the original matlab code:                                                       #####
#####                                                                                                                          #####
#####    !!! weights and bounds not yet considered (no bound-constraint nonlinear least squares solver in scipy)               #####
#####    !!! no extra term phi_n+1                                                                                             #####
#####    ??? nBeta possibly set automatically by parsing the ada code / output (maybe a flag "extra"?)                         #####
#####                                                                                                                          #####
#####  RENAMING                                                                                                                #####
#####    c --->  beta   vector of linear parameters                                                                            #####
#####    n ---> nBeta   number of linear parameters (presently identical to number of phi functions!!!)                        #####
#####    q ---> nAlfa   number of nonlinear parameters                                                                         #####
#####    y ---> yObs    measurement vector                                                                                     #####
#####                                                                                                                          #####
####################################################################################################################################

import numpy as np
from scipy.optimize import leastsq

eps = 1e-8  # machine epsilon

####################################################################################################################################

def varPro (yObs, alfa, nBeta, ada, modelArgs=(), lb=None, ub=None):
	"""  VARPRO = Variable Projection --- Solve a separable nonlinear least squares problem.

	ARGUMENTS:
	----------
        yObs  m x 1   vector containing the m observations.
        alfa  q x 1   initial estimates of the parameters alpha.
        nBeta         number of linear parameters beta
        ada           a function handle, described below.
        lb    q x 1   lower bounds on the parameters alpha.
        ub    q x 1   upper bounds on the parameters alpha.

	RETURNS:
	--------
	alfa          vector of estimates of the nonlinear parameters.
	beta          vector of estimates of the linear parameters.
        yResiduum     residual vector yObs-yMod = yObs-sum(beta*phi)
        resNorm       norm of yResiduum
	"""

	#print ('modelArgs:', type(modelArgs), len(modelArgs), modelArgs)
	# some argument checks
	if len(yObs.shape)==1:    m = len(yObs)
	else:                     raise ValueError ("ERROR --- varpro:  yObs and w must be column vectors of the same length")

	if   len(alfa)<1:         raise ValueError ("ERROR --- varpro:  no nonlinear parameters, use linear LS solver directly")
	elif len(alfa.shape)==1:  nAlfa = len(alfa)
	else:                     raise ValueError ("ERROR --- varpro:  alpha must be a column vector with initial guesses")

	if nBeta<=1:  raise ValueError ("ERROR --- varPro: zero or one linear parameter not yet supported")

	if isinstance(lb,np.ndarray) or  isinstance(ub,np.ndarray):
		raise ValueError ("ERROR --- varpro:  lower and/or upper boinds not yet implemented")

	# Make the first call to ada and do some error checking.
	# phi: a matrix of m rows and nBeta or nBeta+1 columns
	phi, dPhi_dAlfa, index = ada(alfa, *modelArgs)
	#awrite (np.c_[yObs,phi], '/tmp/varPro_phi')

	if not nBeta==phi.shape[1]:  raise ValueError ("ERROR - var_Pro:  no support (yet) for extra phi term independent of beta")

	# check size/shape of arrays (vectors and matrices)
	if not phi.shape[0]==dPhi_dAlfa.shape[0]:
		raise ValueError ("ERROR --- varpro:  inconsistent number of rows of phi and dPhi_dAlfa")
	if not nBeta<=phi.shape[1]<=nBeta+1:
		raise ValueError ("ERROR --- varpro:  The number of columns in Phi must be n or n+1")
	if not (len(index.shape)==2 and index.shape[0]==2):
		raise ValueError ("ERROR --- varpro:  In user function ada: index must have two rows.")
	if not dPhi_dAlfa.shape[1]==index.shape[1]:
		raise ValueError ("ERROR --- varpro:  In user function ada: dPhi and index must have the same number of columns.")

	# Solve the least squares problem (ignore the pure linear case, i.e. "empty" alfa)
	args = tuple([ada, yObs] + list(modelArgs))  # extra arguments to the function and Jacobian used by leastsq
	alfa, alfaCov, infoDict, infoMsg, infoFlag = leastsq (fct4nls, alfa, args, jac4nls, True)
	yResiduum = infoDict["fvec"]

	print ("leastsq ---> msg   ", type(infoMsg), len(infoMsg), infoMsg, infoFlag)

	# given the final nonlinear parameters estimate the linear parameters using linear least squares
	beta = solve_linear_beta (alfa, *args)[0]

	# residuum and measurement vector norm
	resNorm  = np.linalg.norm(yResiduum)
	yObsNorm = np.linalg.norm(yObs)
	#                                                                     probably not yet correct, some further factors ???
	regressionSigma = np.sqrt(resNorm**2 / (m-len(alfa)-len(beta)))

	print('\n VARPRO Results:')
	print  (' NonLinear Parameters  (alfa): ', nAlfa*' %14.6g ' % tuple(alfa))
	print  (' Linear    Parameters  (beta): ', nBeta*' %14.6g ' % tuple(beta))
	print('\n Norm of weighted residual     = %14.6g    (squared: %12.5g)' % (resNorm, resNorm**2))
	print ( ' Norm of data vector (obs)     = %14.6g    (squared: %12.5g)' % (yObsNorm, yObsNorm**2))
	print ( ' Number of function, jacobian calls:  %i %i                 ' % (infoDict['nfev'], infoDict['njev']))
	print ( ' leastsq --- nonlinea least squares:  flag=%i  %s' % (infoFlag, infoMsg))
	print( ' Expected error of observations = %14.6g' % regressionSigma)
	if isinstance(alfaCov,np.ndarray):
		print('\n Covariance(alfa):')
		for i in range(alfaCov.shape[0]):  print ((alfaCov.shape[1]*' %10.4g') % tuple(alfaCov[i,:]))
	print (" leastsq status", infoFlag, infoMsg, " with", infoDict['nfev'], " function evaluations")

	return alfa, beta, yResiduum, resNorm


####################################################################################################################################


def fct4nls (alfa, *extraArgs):
	""" function used by the nonlinear least squares solver to compute the current residual. """

	yObs = extraArgs[1]
	# estimate linear parameter vector `beta` for current nonlinear parameter estimate `alfa`
	beta, phi = solve_linear_beta (alfa, *extraArgs)[:2]

	# observed - model
	yResiduum = yObs -  np.dot(phi[:,:len(beta)], beta)
	#awrite (yResiduum, comments=str('alfa'+len(alfa)*' %10g' + '   beta'+len(beta)*' %10g' + ' ===> yResiduum') %
	#                              tuple(np.r_[alfa, beta]))

	return yResiduum


def jac4nls (alfa, *extraArgs):
	""" function used by the nonlinear least squares solver to compute the current Jacobian. """

	yObs = extraArgs[1]
	m     = len(yObs)
	nAlfa = len(alfa)

	# estimate linear parameter vector `beta` for current nonlinear parameter estimate `alfa`
	beta, phi, dPhi_dAlfa, index, uMatrix, sVector, vTranspose = solve_linear_beta (alfa, *extraArgs)

	nBeta = len(beta)
	# observed - model
	yResiduum = yObs -  np.dot(phi[:,:nBeta], beta)

	# no weights, hence no WdPhi
	dPhi_r = dPhi_dAlfa.T @ yResiduum
	T2 = np.zeros([nBeta, nAlfa])
	jac1 = np.zeros([phi.shape[0], nAlfa])

	if nBeta<phi.shape[1]:  betaTemp = np.append(beta, 1.0)  # extra
	betaTemp = beta

	for j in range(nAlfa):
		for k in range(index.shape[1]):
			if index[1,k]==j:
				jac1[:,j] += dPhi_dAlfa[:,k] * betaTemp[index[0,k]]
				T2[index[0,k],j] = dPhi_r[k]

	rankPhi = len(sVector)
	jac1 = uMatrix[:,rankPhi:m] @  (uMatrix[:,rankPhi:m].T @ jac1)

	T2 = (1/sVector) * (vTranspose[:,:rankPhi] @ T2[:nBeta,:]).T
	#T2 = (1/sVector) * (vTranspose[:,:rankPhi] @ T2[:nBeta,:])
	jac2 = uMatrix[:,:rankPhi] @ T2.T

	jacobian = -jac1 - jac2
	#awrite (jacobian, comments=str('alfa'+len(alfa)*' %10g' + '   beta'+len(beta)*' %10g' + ' ===> jacobian') %
	#                               tuple(np.r_[alfa, beta]))

	return jacobian


####################################################################################################################################

def solve_linear_beta (alfa, *extraArgs):
	""" Estimate linear parameter vector `beta` for current nonlinear parameter estimate `alfa`. """

	ada  = extraArgs[0]
	yObs = extraArgs[1]

	# evaluate individual model functions
	phi, dPhi_dAlfa, index = ada(alfa, *extraArgs[2:])

	m     = len(yObs)
	nBeta = phi.shape[1]

	# Singular value decomposition (returns two unitary matrices U, V and a vector S)
	uMatrix, sVector, vTranspose = np.linalg.svd (phi[:,:nBeta])

	tol = m*eps
	rankPhi = sum(sVector > tol*sVector[0] ) # number of singular values > tol*norm(W*Phi)
	sVector = sVector[:rankPhi]

	if rankPhi<nBeta:  raise ValueError (""" Warning from VARPRO:
	                         The linear parameters are currently not well-determined.
	                         The rank of the matrix in the subproblem is %d
	                         which is less than the n=%d linear parameters """ % (rankPhi, nBeta))

	# dot product of individual U columns with the model vector
	#emp = np.dot   (uMatrix[:,:rankPhi].T, yObs)
	#emp = np.matmul(uMatrix[:,:rankPhi].T, yObs)
	temp =           uMatrix[:,:rankPhi].T @ yObs
	beta = vTranspose.T[:,:rankPhi] @ (temp/sVector)

	return beta, phi, dPhi_dAlfa, index, uMatrix, sVector, vTranspose
