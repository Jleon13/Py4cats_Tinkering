"""
Beer InfraRed Retrieval Algorithm

Various versions/implementation of functions and corresponding Jacobians for nonlinear and separable least squares.

Usage:
xFinal, xCov, infoDict,infoMsg,infoFlag = leastsq (birra_function, xInit,
                                                   (tods, uGrid, cosSZA_I_sun_ToA, srfGauss, wGrid, radObs),
                                                   birra_jacobian, 1)

The tuple in the second row comprises the extra arguments passed thru to birra_function and birra_jacobian
(Note that radObs is not used by birra_jacobian, but the function calls have to be identical).
"""

# HISTORY:   20oct21-fgs    renamed I_sun_ToA ---> cosSZA_I_sun_ToA   (no algorithmic changes)
#                           scaled albedo=reflectivity by 1/pi

try:                        import numpy as np
except ImportError as msg:  raise SystemExit (str(msg) + '\nimport numpy (numeric python) failed!')

from py4cats.var.ir  import recPi
from py4cats.var.srf import Gauss

__all__ = """birra_function    birra_jacobian
             birra_function_vV birra_jacobian_vV
             birra_ada
             gauss_responseFunction convolveTable1D convolveTable2D""".split()

####################################################################################################################################

def birra_function (xVector, tods, uGrid, cosSZA_radSunToA, srfData, wGrid, radObs):
	"""
	Forward model = SWIR radiative transfer for `Beer InfraRed Retrieval Algorithm`.
	(constant or linear reflectivity r(v)=r0+v*r1, i.e. r1 is optional)

	ARGUMENTS:
	----------
	xVector              state vector of unknowns to be fitted
	                     xVector[:nGases]  =  alfa  =  molecular scaling factors (same order as for tods!!!)
	                     xVector[nGases:]  =  beta  =  reflectivity polynomial coefficients r0 [, r1]
	tods                 Total Optical DepthS per molecule (double slant path up+down, columns in same order as for alfa!!!)
	uGrid                monochromatic wavenumber grid (same for all tods)
	cosSZA_radSunToA     incoming solar radiation at top-of-atmosphere,
	                     e.g. cos(SZA)*pi*(sunRadius/sun2earth)**2*planck(v,T_sun)
	                     if observed radiances are already "normalized" by sun reference spectra, set to cos(SZA)
	srfData              Gaussian spectral response data (symmetric)
	wGrid                wavenumber grid of observed spectrum
	radObs               radiance of observed spectrum

	RETURNS:
	--------
	deltaRadiance = radObs-radMod = residual radiance vector
	"""
	nAlfa = tods.shape[1]        # nonlinear parameters, i.e. molec scaling factors
	nBeta = len(xVector)-nAlfa   #    linear parameters, i.e. reflectivity polynomial coefficients
	transmission = np.exp(-np.dot(tods,xVector[:nAlfa]))

	if   nBeta==1:  albedo = xVector[nAlfa]
	elif nBeta==2:  albedo = xVector[nAlfa] + xVector[nAlfa+1]*(uGrid-uGrid[0])/(uGrid[-1]-uGrid[0])
	else:           raise SystemExit ("ERROR --- birra_function:  invalid number of linear parameters (reflectivity 0|1)")

	if len(srfData.shape)==1:  radMod = convolveTable1D (uGrid, recPi*albedo*cosSZA_radSunToA*transmission, srfData, wGrid)
	else:                      radMod = convolveTable2D (uGrid, recPi*albedo*cosSZA_radSunToA*transmission, srfData, wGrid)

	return radObs - radMod


def birra_jacobian (xVector, tods, uGrid, cosSZA_radSunToA, srfData, wGrid, radObs):
	"""
	Jacobian for SWIR radiative transfer for `Beer InfraRed Retrieval Algorithm`.
	(constant or linear reflectivity r(v)=r0+v*r1 with r1 optional)

	Note:  radObs is not used, but kept in the argument list for consistency with birra_function
	       (this is probably also required by the least squares solver).
	"""
	nx    = len(xVector)   # number of fit parameters
	nAlfa = tods.shape[1]  # nonlinear parameters, i.e. molec scaling factors
	nBeta = nx-nAlfa       #    linear parameters, i.e. reflectivity polynomial coefficients
	transmission = np.exp(-np.dot(tods,xVector[:nAlfa]))
	albedo       = xVector[nAlfa]
	jacMono      = np.empty((uGrid.size, xVector.size))
	jacMono[:,nAlfa] = -recPi*cosSZA_radSunToA*transmission  # derivative w.r.t. refl[0] = constant albedo      !!! MINUS because y=yObs-yMod
	if nBeta==2:  # no further tests (already done in birra_function)
		uGridNorm          = (uGrid-uGrid[0])/(uGrid[-1]-uGrid[0])
		albedo            += xVector[nAlfa+1]*uGridNorm
		jacMono[:,nAlfa+1] = jacMono[:,nAlfa] * uGridNorm  # derivative w.r.t. refl[1]
	for j in range(nAlfa):  # derivatives w.r.t. molec scale factors
		jacMono[:,j] = -albedo*jacMono[:,nAlfa]*tods[:,j]  # derivative w.r.t. molec scale factors

	if len(srfData.shape)==1:  radJac = convolveTable1D (uGrid, jacMono, srfData, wGrid)  # single SRF for all wavenumbers
	else:                      radJac = convolveTable2D (uGrid, jacMono, srfData, wGrid)  # individual SRFs w-dependent

	return radJac


####################################################################################################################################
##################################################  single reflective cloud       ##################################################
####################################################################################################################################

def birra_function_vV (xVector, todsAtm, todsAC, uGrid, cosSZA_radSunToA, srfData, wGrid, radObs):
	"""
	Forward model = SWIR radiative transfer for `Beer InfraRed Retrieval Algorithm`.
	Single reflective cloud approximation, i.e. two reflectivities for surface and cloud (top or ...?)

	todsAtm      Total Optical DepthS per molecule (double slant path up+down BoA-ToA)
	todsAC       Total Optical DepthS per molecule (double slant path up+down cloud-ToA)
	             (for both opt depths: columns in same order as for alfa!!!)
        (all other arguments are identical to the 'standard/classical' birra_function

	NOTE:        additional extinction by the cloud could be treated with an extra optical depth!?!
	"""

	# nonlinear parameters: molecular scaling factors
	if todsAtm.shape[1]==todsAC.shape[1]:  nAlfa = todsAtm.shape[1]
	else:                                  raise ValueError ("ERROR --- birra_function_vV:  inconsistent size of opt depths")
	# linear parameters: two reflectivities for surface and cloud
	nBeta = len(xVector)-nAlfa
	if nBeta==2:  albedo, cloud = xVector[nAlfa:]
	else:         raise ValueError ("ERROR --- birra_funcion_vV: invalid length of xVector, expected two linear parameters")

	# radiance at top-of-atmos
	transAtm    = np.exp(-np.dot(todsAtm,xVector[:nAlfa]))   # entire atmosphere BoA-ToA
	transAC     = np.exp(-np.dot(todsAC, xVector[:nAlfa]))   # partial atmosphere above cloud
	radianceToA = recPi*cosSZA_radSunToA*(albedo*transAtm + cloud*transAC)

	if len(srfData.shape)==1:  radMod = convolveTable1D (uGrid, radianceToA, srfData, wGrid)
	else:                      radMod = convolveTable2D (uGrid, radianceToA, srfData, wGrid)
	return radObs - radMod


def birra_jacobian_vV (xVector, todsAtm, todsAC, uGrid, cosSZA_radSunToA, srfData, wGrid, radObs):
	"""
	Jacobian for SWIR radiative transfer for `Beer InfraRed Retrieval Algorithm`.
	Single reflective cloud approximation, i.e. two reflectivities for surface and cloud (top or ...?)

	todsAtm      Total Optical DepthS per molecule (double slant path up+down BoA-ToA)
	todsAC       Total Optical DepthS per molecule (double slant path up+down cloud-ToA)
	             (for both opt depths: columns in same order as for alfa!!!)
	"""

	nAlfa = todsAtm.shape[1]                # nonlinear parameters: molecular scaling factors
	albedo, cloud = xVector[nAlfa:nAlfa+2]  #    linear parameters: two reflectivities

	# monochrom transmissions to top-of-atmos
	transAtm = np.exp(-np.dot(todsAtm,xVector[:nAlfa]))   # entire atmosphere BoA-ToA
	transAC  = np.exp(-np.dot(todsAC, xVector[:nAlfa]))   # partial atmosphere above cloud

	jacMono      = np.empty((uGrid.size, xVector.size))
	jacMono[:,nAlfa]   = -recPi*cosSZA_radSunToA*transAtm  # derivative w.r.t. surface reflectivity
	jacMono[:,nAlfa+1] = -recPi*cosSZA_radSunToA*transAC   # derivative w.r.t. cloud reflectivity

	for j in range(nAlfa):  # derivatives w.r.t. molec scale factors
		jacMono[:,j] = -albedo*jacMono[:,nAlfa]*todsAtm[:,j] -cloud*jacMono[:,nAlfa+1]*todsAC[:,j]
	if len(srfData.shape)==1:  radJac = convolveTable1D (uGrid, jacMono, srfData, wGrid)  # single SRF for all wavenumbers
	else:                      radJac = convolveTable2D (uGrid, jacMono, srfData, wGrid)  # individual SRFs w-dependent

	return radJac


####################################################################################################################################
##################################################    variable   projection       ##################################################
##################################################    separable least squares     ##################################################
####################################################################################################################################

def birra_ada (alfa, nBeta, tods, uGrid, cosSZA_radSunToA, srfData, wGrid, radObs):
	"""
	Forward model = SWIR radiative transfer for `Beer InfraRed Retrieval Algorithm`.
	(constant, linear, or quadrativ reflectivity r(v)=r0+v*r1_v*v*r2, with r1 (and r2) optional)

	This version adjusted to varPro returns the model components for different reflectivity coefficients separately.
	"""

	if len(alfa)!=tods.shape[1]:  raise ValueError ("ERROR - birra_ada: inconsitent size of alfa and tods")
	if not 1<=nBeta<=3:           raise ValueError ("ERROR - birra_ada: non-positive or excessive number of reflectivities")

	nAlfa = tods.shape[1]        # nonlinear parameters, i.e. molec scaling factors
	phiMono        = np.zeros([len(uGrid), nBeta])
	dPhiMono_dAlfa = np.zeros([len(uGrid), nAlfa*nBeta])
	index          = np.zeros([2, nAlfa*nBeta], int)

	# monochromatic molecular absorption (all gases, slant double path sun-earth-satellite)
	transmission = np.exp(-np.dot(tods,alfa))

	# the nonlinear model function and its partial derivatives for the constant reflectivity term r0
	phiMono[:,0] = recPi*cosSZA_radSunToA*transmission
	for m in range(nAlfa):
		dPhiMono_dAlfa[:,m] = -tods[:,m]*phiMono[:,0]  # dPhi0 / dAlfa_m
		index[:,m]          = np.array([0,m])

	if nBeta>1:
		uReduced = (uGrid-uGrid[0])/(uGrid[-1]-uGrid[0])
		for j in range(1,nBeta):
			phiMono[:,j]            = phiMono[:,j-1] * uReduced
			for m in range(nAlfa):
				dPhiMono_dAlfa[:,nAlfa*j+m] = dPhiMono_dAlfa[:,nAlfa*(j-1)+m] * uReduced  # dPhi_j / dAlfa_m
				index[:,nAlfa*j+m]      = np.array([j,m])

	# convolution with spec response
	if len(srfData.shape)==1:  # single SRF for all wavenumbers
		phi        = convolveTable1D  (uGrid, phiMono,        srfData, wGrid)
		dPhi_dAlfa = convolveTable1D  (uGrid, dPhiMono_dAlfa, srfData, wGrid)
	else:  # individual SRFs w-dependent
		phi = convolveTable2D        (uGrid, phiMono,        srfData, wGrid)
		dPhi_dAlfa = convolveTable2D (uGrid, dPhiMono_dAlfa, srfData, wGrid)

	return phi, dPhi_dAlfa, index


####################################################################################################################################
####################################################################################################################################
##################################################  spectral response functions   ##################################################
####################################################################################################################################
####################################################################################################################################

def gauss_responseFunction (vGrid, hwhm=1.0, nWidths=5.0):
	""" Evaluate Gauss response function (normalized to one) on (wavenumber) grid of monochromatic spectrum.

	ARGUMENTS:
	----------
	vGrid      wavenumber grid of the monochromatic spectrum/spectra (uniform/equidistant)
	hwhm       half-width at half maximum
	nWidths    extension of the Gaussian (left and right) in units of the half width

	RETURNS:
	--------
	srfArray   response function values
	"""

	deltaV = np.ediff1d(vGrid)
	if max(deltaV)-min(deltaV)>0.01*deltaV[0]:
		raise SystemExit ("ERROR --- convolveGauss:  monochromatic wavenumber grid not equidistant")
	else:
		deltaV = deltaV.mean()  # simply replace, array not needed anymore
		recDelta = 1.0/deltaV

	# evaluate response function on dense grid with spacing as monochromatic grid
	nRight = int(nWidths*hwhm*recDelta)
	rGrid = vGrid[:nRight+1]-vGrid[0]                      # right side grid
	sGrid = np.concatenate((-np.flipud(rGrid[1:]),rGrid))  # symmetrically around 0
	srfArray   = Gauss(sGrid, hwhm)

	return srfArray


def gauss_responseFunctions_matrix (vGrid, halfWidths, nWidths=5.0):
	""" Evaluate Gauss response functions (normalized to one) on (wavenumber) grid of monochromatic spectrum.
            Similar to gauss_responseFunction, but for a list (array) of half widths.

	    Returns a 2D array with len(halfWidths) columns.
	"""
	maxWidth = max(halfWidths)
	srFunctions = [gauss_responseFunction(vGrid, w, nWidths*maxWidth/w) for w in halfWidths]
	return np.array(srFunctions).T

def gauss_responseFunction_list (vGrid, halfWidths, nWidths=5.0):
	""" Evaluate Gauss response functions (normalized to one) on (wavenumber) grid of monochromatic spectrum.
            Similar to gauss_responseFunction, but for a list (array) of half widths.

	    Returns a list of 1D arrays with len(halfWidths) elements.
	"""
	srFunctions = [gauss_responseFunction(vGrid, w, nWidths) for w in halfWidths]
	return srFunctions


####################################################################################################################################
#######################################################      convolution     #######################################################
####################################################################################################################################

def convolveTable1D (vGrid, yValues, srfData, wGrid):
	""" Convolve spectra with a single/common tabulated spectral response function.

	    vGrid:     the wavenumber grid of the monochromatic (high resolution) spectra
	               should be equidistant and monotone increasing
	    yValues:   a rank-1 spectrum or rank-2 array (matrix) of spectra defined on vGrid
	    srfData:   response function defined for a spacing as given by vGrid
	    wGrid:     new wavenumber grid

	    For efficiency no tests of the input arguments are performed!
	    (Use gauss_responseFunction to setup `srfData`).
	"""

	deltaV   = (vGrid[-1]-vGrid[0]) / (len(vGrid)-1)
	recDelta = 1.0/deltaV
	nRight   = int(srfData.shape[0]/2)

	if len(yValues.shape)==1:
		# allocate smoothed spectra
		yConvolved = np.zeros(len(wGrid))
		# and loop over Gaussians
		for i,ww in enumerate(wGrid):
			iMid  = int(recDelta*(ww-vGrid[0]))  # index of center point in fine grid
			# multiply monochromatic spectrum with Gauss and integrate
			if iMid-nRight<0 or iMid+nRight+1>len(vGrid):
				print ("WARNING:", i, ww, iMid, vGrid[iMid], iMid-nRight, iMid+nRight+1)
			yConvolved[i] = np.trapz (yValues[iMid-nRight:iMid+nRight+1]*srfData, dx=deltaV)
	elif len(yValues.shape)==2:
		yConvolved = np.zeros((len(wGrid),yValues.shape[1]))
		# and loop over Gaussians
		for i,ww in enumerate(wGrid):
			iMid  = int(recDelta*(ww-vGrid[0]))  # index of center point in fine grid
			for j in range(yValues.shape[1]):
				yConvolved[i,j] = np.trapz (yValues[iMid-nRight:iMid+nRight+1,j]*srfData, dx=deltaV)
	else:
		raise SystemExit ('ERROR --- convolveGauss:  unknown shape/type of spectral response data,\n',
		                  '                          need rank 1 (spectrum) or rank 2 array (spectra)')
	return  yConvolved


def convolveTable2D (vGrid, yValues, srfData, wGrid):
	""" Convolve spectra with tabulated spectral response functionS.

	    vGrid:     the wavenumber grid of the monochromatic (high resolution) spectra
	               should be equidistant and monotone increasing
	    yValues:   a rank-1 spectrum or rank-2 array (matrix) of spectra defined on vGrid
	    srfData:   response functionS defined for a spacing as given by vGrid
	               individual responses for each final wavenumber grid points, i.e. srfData.shape[1]==len(wGrid)
	    wGrid:     new wavenumber grid

	    For efficiency no tests of the input arguments are performed!
	    (Use gauss_responseFunctions to setup `srfData`).
	"""

	deltaV   = (vGrid[-1]-vGrid[0]) / (len(vGrid)-1)
	recDelta = 1.0/deltaV
	nRight   = int(srfData.shape[0]/2)

	if len(yValues.shape)==1:
		# allocate smoothed spectra
		yConvolved = np.zeros(len(wGrid))
		# and loop over Gaussians
		for i,ww in enumerate(wGrid):
			iMid  = int(recDelta*(ww-vGrid[0]))  # index of center point in fine grid
			# multiply monochromatic spectrum with Gauss and integrate
			if iMid-nRight<0 or iMid+nRight+1>len(vGrid):
				print ("WARNING:", i, ww, iMid, vGrid[iMid], iMid-nRight, iMid+nRight+1)
			yConvolved[i] = np.trapz (yValues[iMid-nRight:iMid+nRight+1]*srfData[:,i], dx=deltaV)
	elif len(yValues.shape)==2:
		yConvolved = np.zeros((len(wGrid),yValues.shape[1]))
		# and loop over Gaussians
		for i,ww in enumerate(wGrid):
			iMid  = int(recDelta*(ww-vGrid[0]))  # index of center point in fine grid
			for j in range(yValues.shape[1]):
				yConvolved[i,j] = np.trapz (yValues[iMid-nRight:iMid+nRight+1,j]*srfData[:,i], dx=deltaV)
	else:
		raise SystemExit ('ERROR --- convolveGauss:  unknown shape/type of spectral data,\n',
		                  '                          need rank 1 (spectrum) or rank 2 array (spectra)')

	return  yConvolved
