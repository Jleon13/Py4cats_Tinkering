"""
SVEEEETIES --- Singular Vector Expansion to Estimate Exoplanet Earth-like Temperatures from Infrared Emission Spectra

F. Schreier et al.,  A&A 633, A156, 2020, doi: 10.1051/0004-6361/201936511
                     arxiv eprint 1912.09706
"""

####################################################################################################################################

# import some standard python modules
import os

try:
	import numpy as np
	from scipy.optimize import leastsq, least_squares
except ImportError as msg:
	raise SystemExit (str(msg) + '\nimport numpy and scipy failed!')

try:
	from matplotlib.pyplot import figure, subplot, plot, twiny, legend, xlabel, ylabel, yticks, title, text, errorbar, xlim
except ImportError as msg: print ("WARNING --- import matplotlib.pyplot failed!\n" + str(msg))


from .. lbl.lbl2od import lbl2od
from .. art.od2ri import dod2ri
from .. art.atmos1D import atmPlot, atmSave
from .. var.aeiou import minmaxmean, awrite
from .. var.cgsUnits import cgs
from .. var.radiance2Kelvin import radiance2Kelvin
from .. var.struc_array import strucArrayAddField
from .. inv.tools import linLstSquares

#nForward=-1

####################################################################################################################################
####################################################################################################################################

def sveeeeties (atmMod, radObs, baseVectors, dictLineList,
                surface=False, xTol=1e-3, yTol=1e-3, oldLS=True, name=None):
	""" Singular Vector Expansion to Estimate Exoplanet Earth-like Temperatures from Infrared Emission Spectra:
	    Given line, (model) atmospheric data AND a (synthetic) radiance 'observation',
	    perform a nonlinear least squares to retrieve the temperature profile defined by an expansion.

	ARGUMENTS:
	atmMod      a structured numpy array with atmospheric data (pressure and molec concentrations vs. altitude
	            if temperature is not included, generate first guess T from min and max equiv. brightness spectrum
	radObs      observed radiance spectrum ("riArray", subclassed numpy array including attributes such as wavenumber limits)
	baseVectors len(zGrid)*len(x) "matrix" (where x is the array of expansion coefficients to be estimated);
	            originally given by the U-matrix resulting from the SVD of a matrix of "representative" temperature profiles,
		    but any (reasonable) set of vectors can be used (e.g. Chebychev polynomials)
	dictLineList  dictionary of line lists (Hitran or Geisa excerpt returned by higstract)
	surface     flag to include surface thermal emission (assuming T_surf = T(BoA))
	xTol, yTol  tolerances for least squares convergence tests
	name        name of planet etc, used to trigger verbose output (print and plot)

	RETURNS:
	a dictionary of results, esp. the temperature profile along with its errors
	"""
	verbose = isinstance(name, str)

	if os.path.isfile('sveeeeties.log') and verbose:
		with open('sveeeeties.log','a') as logFile:
			logFile.write(str('\n\n%s  ' + 100*'#' + '\n\n') % name);  logFile.close()

	# initial guess
	if 'T' not in atmMod.dtype.names:
		eqBT = radObs.kelvin()  # equivalent brightness temperature
		tmpMin, tmpMax = min(eqBT), max(eqBT)
		zGrid, zMax = atmMod['z'], atmMod['z'][-1]  # zMin=0.0
		atmMod = strucArrayAddField(atmMod, (zGrid*tmpMin + (zMax-zGrid)*tmpMax)/zMax, 'T')

	if verbose:
		awrite ([cgs('!km',atmMod['z']), atmMod['T']], name+'.zTi', '%6.1f %10.3f')
		figure(name)

	# nonlinear least squares fit of temperature expansion coefficients to infrared emission spectrum
	tFit, lsqDict = fitTempExpCoeff (atmMod, radObs, baseVectors, dictLineList, surface, xTol, yTol, oldLS, verbose)

	if verbose:
		legend(prop={'family': 'monospace',  'size': 'small'})
		title('%s  %i %g' % (name, lsqDict['nfev'], lsqDict['cost']))

	## finally evaluate model spectrum and save temperature and spectrum
	radFinal = radObs.base - lsqDict['fVec']
	normFinal = lsqDict['cost']  # np.linalg.norm(radFinal-radObs.base)
	meanDeltaBT = np.mean(abs(radiance2Kelvin(radObs.grid(),radFinal)-radObs.kelvin()))
	print ("final   radiance residuum norm %g %.2fK" % (normFinal, meanDeltaBT))

	# estimate errors
	nBase = baseVectors.shape[1];  awrite(baseVectors)
	if isinstance(lsqDict.get('xCov'), np.ndarray):
		xErr = np.sqrt(np.diag(lsqDict['xCov'])/(len(radObs)-nBase))*normFinal;  print ('xErr', xErr.shape, xErr)
		tErr = np.sqrt(np.sum(baseVectors**2*xErr**2,1));  print ('tErr', tErr.shape, tErr)
	else:
		xErr = np.full(baseVectors.shape[1], np.nan)
		tErr = np.full(len(tFit),            np.nan)

	if verbose:
		comments = [nBase*' %12g' % tuple(lsqDict['x']),
		            nBase*' %12g' % tuple(xErr),
		            "nFctEv=%i cost=%g  flag=%i" % (lsqDict['nfev'], lsqDict['cost'], lsqDict['flag']),
		            lsqDict['msg'].replace('\n','')]
		awrite ([cgs('!km',atmMod['z']), tFit, tErr], name+'.zTf', '%6.1f %10.3f', comments=comments)
		awrite ([radObs.grid(), radFinal], name+'.vIf', '%6.1f %12.4g', comments=comments)
		lsqDict['T']   = tFit
		lsqDict['err'] = tErr
		lsqDict['dBT'] = meanDeltaBT
		return lsqDict
	else:
		return tFit


####################################################################################################################################

def fitTempExpCoeff (atmos, radianceObs, baseVectors, llDict, surface=False, xTol=1e-03, yTol=1e-03, oldLS=True, plotIter=False):
	""" Nonlinear least squares fit of coefficients of temperature expansion in a set of base vectors (e.g. singular vectors).
	    (leastsq version) """

	# initial guess coefficients
	xInit  = np.linalg.lstsq(baseVectors, atmos['T'])[0]
	print (160*'#', '\n', " init guess coefficients", xInit)
	if plotIter:  atmPlot(atmos, marker='x', label=len(xInit)*'%12f' % tuple(xInit) + ' xInit')
	atmSave (atmos, 'atmos.ini', units=1)

	if oldLS:
		xFinal, xCov, infoDict,infoMsg,infoFlag = leastsq (lbl2schwarzschild_tempFit, xInit,
								   full_output=1, xtol=xTol, ftol=yTol,
								   args=(baseVectors, radianceObs, atmos, llDict, surface, plotIter))
		radResNorm = np.linalg.norm(infoDict.get('fvec', -1))
		lsqDict    = dict(x=xFinal, xCov=xCov, nfev=infoDict['nfev'], fVec=infoDict['fvec'], jac=infoDict['fjac'],
		                  cost=radResNorm, msg=infoMsg, flag=infoFlag)
	else:
		result = least_squares (lbl2schwarzschild_tempFit, xInit,
		                        method='lm', xtol=xTol, ftol=yTol,
					args=(baseVectors, radianceObs, atmos, llDict, surface, plotIter))
		xFinal     = result['x']
		radResNorm = np.sqrt(2.*result['cost'])
		lsqDict    = dict(x=xFinal, nfev=result['nfev'], fVec=result['fun'], jac=result['jac'],
		                  cost=radResNorm, msg=result['message'], flag=result['success'])

	# report the least squares fit
	print (" final coefficients", xFinal, "  with  resNorm", radResNorm,
	       "\n status", lsqDict['flag'], lsqDict['msg'], " with", lsqDict['nfev'], " function evaluations")

	# reconstruct the final temperature profile
	temperature = np.dot(baseVectors,xFinal)
	if plotIter:  plot (temperature, cgs('!km', atmos['z']), color='r', marker='+', lw=3,
	                    label=len(xFinal)*'%12f' % tuple(xFinal) + ' xFinal')

	# fvec = residuum vector = obs-mod,  cost = norm(fvec)
	return temperature, lsqDict


####################################################################################################################################

def lbl2schwarzschild_tempFit (xCoefficients,  baseVectors, radObs, atmMod, llDict, surface=False, plotIter=False):
	""" Forward model for nonlinear least squares fit of temperature from thermal emission spectrum.

	    Given line and atmospheric data and coefficients of basis functions used for the temperature expansion
	    integrate Schwarzschild integral and return radiance (optionally convolved with srf as observed). """

	#global nForward
	#nForward = +1

	print ("\n lbl2schwarzschild_tempFit:  xCoefficients", xCoefficients)

	# reconstruct the temperature profile and update the temperature column in the atmosphere array
	atmMod['T'] = np.dot(baseVectors, xCoefficients)
	if min(atmMod['T'])<1.0:  atmMod['T'] = np.where(atmMod['T']<1, min(radObs.kelvin()), atmMod['T'])

	#if plotIter and nForward%(len(xCoefficients)+1)==0:
	if plotIter:
		atmPlot(atmMod, label=len(xCoefficients)*'%12f' % tuple(xCoefficients), ls='--')

	# instrument spectral response function
	srfType, srfWidth = radObs.moreAttr['srfType'],  radObs.moreAttr.get('srfValue', 0.0)
	srfWings=5*float(srfWidth)  # 1*width, 2*width would be enough for box, triangle

	# lines --> cross sections --> abs.coefficients --> delta optical depths
	dodList = lbl2od (atmMod, llDict, radObs.x+srfWings)
	# and integrate Schwarzschild
	if surface:  radMod = dod2ri (dodList, obsAngle=radObs.obsAngle, tSurface=atmMod['T'][0], mode='Schwarzschild')
	else:        radMod = dod2ri (dodList, obsAngle=radObs.obsAngle)

	# optionally convolve with response function
	if srfWidth>0.0:
		radModConv = radMod.convolve(float(srfWidth), srfType, radObs.grid())
		delta      = radObs.base - radModConv.base
	else:
		if len(radObs)==len(radMod):  delta=radObs - radMod
		else:                         delta=radObs - radMod.regrid(len(radObs), yOnly=True)

	print(" observed: ", radObs.info())
	print(" modeled:  ", radMod.info())
	if srfWidth>0.0:  print(" modConv:  ", radModConv.info())
	minmaxmean(delta, 'deltaRad')

	if os.path.isfile('sveeeeties.log'):
		logFile = open('sveeeeties.log', 'a')
		logFile.write (str('x' + len(xCoefficients)*' %f' + '\n') % tuple(xCoefficients))
		logFile.write (str('T' + len(atmMod)*' %6.1f' + '\n') % tuple(atmMod['T']))
		logFile.write ('Obs: %s\n' % radObs.info())
		logFile.write ('Mod: %s\n' % radModConv.info())
		logFile.write ('Res: min %10f    max %10f   norm %g\n\n' % (abs(delta).min(), abs(delta).max(), np.linalg.norm(delta)))
		logFile.close()

	return delta


####################################################################################################################################

fontDict = {'color': 'gray',  'size': 'small'}

def plot_temp_fits (zGrid, atmFiles, atmData, fits, baseVectors=None, nRowCol=(3,6), eBar=False):
	""" Plot true vs nonlinear and linear fit temperatures along with differences. """
	i=0
	nRows, nColumns = nRowCol
	for file,data in zip(atmFiles,atmData):
		name = os.path.splitext(file)[0]
		if name not in fits.keys():  continue
		i+=1;  subplot(nRows,nColumns,i)
		atmPlot(data)  # temperatures
		if (i-1)%nColumns>0:
			ylabel("");  yticks(np.arange(zGrid[0],zGrid[-1]+1,10),[])
		if i<=(nRows-1)*nColumns:  xlabel("")
		if eBar: errorbar(fits[name]['T'], zGrid, xerr=fits[name]['err'], color='r', ecolor='r',elinewidth=0.5)
		else:    plot(fits[name]['T'], zGrid, 'r')
		if isinstance(baseVectors,np.ndarray):
			tllsq = linLstSquares(data['T'], baseVectors)
			plot(tllsq, zGrid, 'b')
		if i==12:  legend ('true nonlinear linear'.split())
		twiny()  # delta temperatures
		deltaT = fits[name]['T']-data['T']
		plot(deltaT,zGrid,'r:')
		if isinstance(baseVectors,np.ndarray):  plot(tllsq-data['T'],zGrid,'b:')
		text(xlim()[0]+0.5,zGrid[-1],'%.1f' % np.max(abs(deltaT)),         fontDict, ha='left',  va='top')
		text(xlim()[1]-0.5,zGrid[-1],'%.1f' % np.mean(abs(deltaT)),        fontDict, ha='right', va='top')
		text(xlim()[0]+0.5,zGrid[0], '%.1f' % np.max(abs(deltaT[3:-10])),  fontDict, ha='left',  va='bottom')
		text(xlim()[1]-0.5,zGrid[0], '%.1f' % np.mean(abs(deltaT[3:-10])), fontDict, ha='right', va='bottom')
		title('%s %i %.1fK' % (name, fits[name]['nfev'], fits[name]['dBT']), pad=5)  # ,fontsize='x-small')
