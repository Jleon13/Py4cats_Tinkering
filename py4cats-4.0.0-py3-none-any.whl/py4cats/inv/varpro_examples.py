####################################################################################################################################
#####
#####   VARPRO = Variable Projection --- Solve a separable nonlinear least squares problem.                                    #####
#####
####################################################################################################################################

import numpy as np
from scipy.optimize import leastsq
#from py4cats.xxx.var_pro import varPro

__all__ = ('expCosResidual expCosJacobian expCosModel expCosADA' +
           'expResidual expJacobian expModel expADA' +
           'sinResidual sinJacobian sinModel sinADA').split()


####################################################################################################################################
#####    Python translation of the O'Leary&Rust example (varpro_example.m, adaex.m):   a sum of two exp-damped cosines         #####
#####                                                                                                                          #####
#####    [ The rest of this header is a one-to-one copy of the header of the corresponding matlab file. ]                      #####
#####                                                                                                                          #####
##### varpro_example.m                                                                                                         #####
##### Sample problem illustrating the use of varpro.                                                                           #####
#####                                                                                                                          #####
##### Observations y(t) are given at 10 values of t.                                                                           #####
#####                                                                                                                          #####
##### The model for this function y(t) is                                                                                      #####
#####                                                                                                                          #####
#####   eta(t) = c1 exp(-alpha2 t)*cos(alpha3 t)                                                                               #####
#####          + c2 exp(-alpha1 t)*cos(alpha2 t)                                                                               #####
#####                                                                                                                          #####
##### The linear parameters are c1 and c2, and the                                                                             #####
#####  nonlinear parameters are alpha1, alpha2, and alpha3.                                                                    #####
#####                                                                                                                          #####
##### The two nonlinear functions in the model are                                                                             #####
#####                                                                                                                          #####
#####   Phi1(alpha,t) = exp(-alpha2 t)*cos(alpha3 t),                                                                          #####
#####   Phi2(alpha,t) = exp(-alpha1 t)*cos(alpha2 t).                                                                          #####
#####                                                                                                                          #####
##### Dianne P. O'Leary and Bert W. Rust, September 2010                                                                       #####
####################################################################################################################################

def expCosResidual (xModel, tGrid, yObs):
	""" Compute the "complete" residual function (observed - model(x))

	    yDelta = yObs - yModel(x) =  yObs - b0 exp(-a1*t) cos(a2*t) - b1 exp(-a0*t) cos(a1*t)
	"""

	n = len(xModel)
	if n==5:
		alfa, beta = xModel[:3], xModel[3:]
	else:
		raise SystemExit ("ERROR --- expCosResidual: incorrect number of model parameters, expected 3 nonlinear, 2 linear")

	if len(tGrid)!=len(yObs):
		raise SystemExit ("ERROR --- expCosResidual:  grid vector and measurement vector have different size!")

	return yObs - expCosModel(alfa, beta, tGrid)

def expCosJacobian (xModel, tGrid, yObs):
	""" Compute the Jacobian corresponding to the "complete" residual function (observed - model(x)). """

	n = len(xModel)
	if n==5:
		alfa, beta = xModel[:3], xModel[3:]
	else:
		raise SystemExit ("ERROR --- expCosResidual: incorrect number of model parameters, expected 3 nonlinear, 2 linear")

	if len(tGrid)!=len(yObs):
		raise SystemExit ("ERROR --- expCosResidual:  grid vector and measurement vector have different size!")

	jacobian = np.zeros([len(tGrid),5])
	# derivatives of the model function
	jacobian[:,0] = -tGrid * beta[1] * np.exp(-alfa[0]*tGrid)*np.cos(alfa[1]*tGrid)  # d_yModel / d_alfa0
	jacobian[:,1] = -tGrid * beta[0] * np.exp(-alfa[1]*tGrid)*np.cos(alfa[2]*tGrid)   \
	                -tGrid * beta[1] * np.exp(-alfa[0]*tGrid)*np.sin(alfa[1]*tGrid)  # d_yModel / d_alfa1
	jacobian[:,2] = -tGrid * beta[0] * np.exp(-alfa[1]*tGrid)*np.sin(alfa[2]*tGrid)  # d_yModel / d_alfa2
	jacobian[:,3] =                    np.exp(-alfa[1]*tGrid)*np.cos(alfa[2]*tGrid)  # d_yModel / d_beta0
	jacobian[:,4] =                    np.exp(-alfa[0]*tGrid)*np.cos(alfa[1]*tGrid)  # d_yModel / d_beta0

	# scale by -1 because of the yObs-yModel
	return -jacobian


def expCosModel (alpha, beta, tGrid):
	""" Compute the "complete" model function of the OLeary&Rust example. """
	model = beta[0] * np.exp(-alpha[1]*tGrid)*np.cos(alpha[2]*tGrid) \
	       +beta[1] * np.exp(-alpha[0]*tGrid)*np.cos(alpha[1]*tGrid)
	return model

def expCosADA (alpha, tGrid):
	""" Compute the two nonlinear model function(s) individually. """

	phi        = np.zeros([len(tGrid), 2])
	dPhi_dAlfa = np.empty([len(tGrid), 4])
	index      = np.empty([2, 4])

	# the nonlinear model functions
	phi[:,0] = np.exp(-alpha[1]*tGrid)*np.cos(alpha[2]*tGrid)
	phi[:,1] = np.exp(-alpha[0]*tGrid)*np.cos(alpha[1]*tGrid)

	# partial derivatives (nonzero only)
	dPhi_dAlfa[:,0] = -tGrid * phi[:,0]                                        # dPhi0 / dAlfa1
	dPhi_dAlfa[:,1] = -tGrid * np.exp(-alpha[1]*tGrid)*np.sin(alpha[2]*tGrid)  # dPhi0 / dAlfa2
	dPhi_dAlfa[:,2] = -tGrid * phi[:,1]                                        # dPhi1 / dAlfa0
	dPhi_dAlfa[:,3] = -tGrid * np.exp(-alpha[0]*tGrid)*np.sin(alpha[1]*tGrid)  # dPhi1 / dAlfa1

	# indicator of the nonzero partial derivatives
	# column k of this index matrix describes column k of the Jacobian: the first and second row indicate phi and alfa
	index = np.array([[0, 0, 1, 1],
	                  [1, 2, 0, 1]])

	return phi, dPhi_dAlfa, index


tGrid = np.array([0,.1,.22,.31,.46,.50,.63,.78,.85,.97])
yObs  = np.array([6.9842,  5.1851,  2.8907,  1.4199, -0.2473, -0.5243, -1.0156, -1.0260, -0.9165, -0.6805])
alphaTrue = np.array([1.0, 2.5, 4.0]);   betaTrue = np.array([6, 1])

plot (tGrid, yObs, 'o:', label='obs')
# separable least squares
alphaInit = np.array([0.5, 2.0, 3.0])  # the original init guess used by O'LearyRust
alfa, beta, yDelta, deltaNorm = varPro(yObs, alphaInit, len(betaTrue), expCosADA, (tGrid,))
infoVarPro = str('alfa: ' + len(alfa)*' %8.4f' + '   beta: ' + len(beta)*' %8.4f') % tuple(np.concatenate([alfa,beta]))
plot (tGrid, expCosModel(alfa, beta, tGrid), 'r', label=infoVarPro)
# nonlinear least squares without Jacobian (note that init guess is worse than for varPro!)
xInit = np.concatenate([0.75*np.ones_like(alfa), np.ones_like(beta)])
xVector1, xCovar, infoDict, infoMsg, infoFlag = leastsq (expCosResidual, xInit, (tGrid, yObs), full_output=1)
infoLeastSq = str('leastsq (fd) %i fct eval ==> xVector: ' + len(xVector1)*' %8.4f') % tuple(np.r_[infoDict['nfev'],xVector1])
plot (tGrid, -expCosResidual(xVector1, tGrid, np.zeros_like(tGrid)), 'g--', label=infoLeastSq)
# nonlinear least squares with Jacobian (note that init guess is worse than for varPro!)
xVector2, xCovar, infoDict, infoMsg, infoFlag = leastsq (expCosResidual, xInit, (tGrid, yObs), expCosJacobian, 1)
infoLeastSq = str('leastsq (ad) %i fct eval ==> xVector: ' + len(xVector2)*' %8.4f') % tuple(np.r_[infoDict['nfev'],xVector2])
plot (tGrid, -expCosResidual(xVector2, tGrid, np.zeros_like(tGrid)), 'b-.', label=infoLeastSq)
legend()


####################################################################################################################################
#####    Generalization     of the O'Leary&Rust example (varpro_example.m, adaex.m):   a sum of THREE damped cosines           #####
####################################################################################################################################

def expCosModel3 (alpha, beta, tGrid):
	""" Compute the "complete" model function of the OLeary&Rust example. """
	model = beta[0] * np.exp(-alpha[1]*tGrid)*np.cos(alpha[2]*tGrid) \
	       +beta[1] * np.exp(-alpha[0]*tGrid)*np.cos(alpha[1]*tGrid) \
	       +beta[2] * np.exp(-alpha[3]*tGrid)*np.cos(alpha[0]*tGrid)
	return model


def expCosADA3 (alpha, tGrid):
	""" Compute the two nonlinear model function(s) individually. """

	phi        = np.zeros([len(tGrid), 3])
	dPhi_dAlfa = np.empty([len(tGrid), 6])
	index      = np.empty([2, 6])

	# the nonlinear model functions
	phi[:,0] = np.exp(-alpha[1]*tGrid)*np.cos(alpha[2]*tGrid)
	phi[:,1] = np.exp(-alpha[0]*tGrid)*np.cos(alpha[1]*tGrid)
	phi[:,2] = np.exp(-alpha[3]*tGrid)*np.cos(alpha[0]*tGrid)

	# partial derivatives (nonzero only)
	dPhi_dAlfa[:,0] = -tGrid * phi[:,0]                                        # dPhi0 / dAlfa1
	dPhi_dAlfa[:,1] = -tGrid * np.exp(-alpha[1]*tGrid)*np.sin(alpha[2]*tGrid)  # dPhi0 / dAlfa2
	dPhi_dAlfa[:,2] = -tGrid * phi[:,1]                                        # dPhi1 / dAlfa0
	dPhi_dAlfa[:,3] = -tGrid * np.exp(-alpha[0]*tGrid)*np.sin(alpha[1]*tGrid)  # dPhi1 / dAlfa1
	dPhi_dAlfa[:,4] = -tGrid * phi[:,2]                                        # dPhi2 / dAlfa3
	dPhi_dAlfa[:,5] = -tGrid * np.exp(-alpha[3]*tGrid)*np.sin(alpha[0]*tGrid)  # dPhi2 / dAlfa0

	# indicator of the nonzero partial derivatives
	# column k of this index matrix describes column k of the Jacobian: the first and second row indicate phi and alfa
	index = np.array([[0, 0, 1, 1, 2, 2],
	                  [1, 2, 0, 1, 3, 0]])

	return phi, dPhi_dAlfa, index


alpha3Init = np.array([0.5, 2.0, 3.0, 2.0])
alpha3True = np.array([1.0, 2.0, 4.0, 3.0]);   beta3True = np.array([5, 1, 0.5])

tGrid3 = np.linspace(0.0, 1.0,21)
yObs3  = expCosExample3(alpha3True, beta3True, tGrid3)


####################################################################################################################################
#####                            2.5 more models:  sum of exponentials and sum of sines (cosines)                              #####
####################################################################################################################################

def expResidual (xModel, tGrid, yObs):
	""" Compute the "complete" residual function (observed - model(x))

	    yDelta = yObs - yModel(x) =  yObs - sum b*sin(a*t)
	"""

	n = len(xModel)
	if n%2:     raise SystemExit ("ERROR --- expResidual: incorrect number of model parameters, expected an even number")
	elif n<2:   raise SystemExit ("ERROR --- expResidual: incorrect number of model parameters, expected at least one pair")
	else:       alfa, beta = xModel[:n//2], xModel[n//2:]

	if len(tGrid)!=len(yObs):
		raise SystemExit ("ERROR --- expResidual:  grid vector and measurement vector have different size!")

	return yObs - expModel(alfa, beta, tGrid)


def expJacobian (xModel, tGrid, yObs):
	""" Compute the Jacobian corresponding to the "complete" residual function (observed - model(x)). """

	nExp = len(xModel)//2
	if nExp>0 and len(xModel)-2*nExp==0:
		alfa, beta = xModel[:nExp], xModel[nExp:]
	else:
		raise SystemExit ("ERROR --- expJacobian: incorrect number of model parameters, expected one or more pair(s)")

	if len(tGrid)!=len(yObs):
		raise SystemExit ("ERROR --- expJacobian:  grid vector and measurement vector have different size!")

	jacobian = np.zeros([len(tGrid),2*nExp])
	# derivatives of the model function
	for j,a in enumerate(alfa):
		jacobian[:,j+nExp] = np.exp(a*tGrid)                       # d_yModel / d_beta
		jacobian[:,j]      = tGrid * beta[j] * jacobian[:,j+nExp]  # d_yModel / d_alfa

	# scale by -1 because of the yObs-yModel
	return -jacobian


def expModel (alfa, beta, tGrid):
	""" Compute the "complete" model function (sum of exponentials) as a function of the nonlinear parameters. """
	if len(alfa)==len(beta): model = np.zeros_like(tGrid)
	else:                    raise ValueError ("ERROR --- expModel:  different size of linear and nonlinear parameter arrays!")

	# accumulate the exponentials
	for a,b in zip(alfa,beta):
		model += b*np.exp(a*tGrid)
	return model


def expADA (alfa, tGrid):
	""" Compute the nonlinear model function(s) individually. """
	phi        = np.zeros([len(tGrid), len(alfa)])
	dPhi_dAlfa = np.empty([len(tGrid), len(alfa)])
	index      = np.empty([2, len(alfa)], int)

	for j,a in enumerate(alfa):
		phi[:,j]        =       np.exp(a*tGrid)
		dPhi_dAlfa[:,j] = tGrid*np.exp(a*tGrid)
		index[:,j]      = [j,j]

	return phi, dPhi_dAlfa, index


tGrid = linspace(0.0,1.0,11)
alfa, beta = [1.0, 2.0], [1.0,-0.5]
yObs = expModel(alfa, beta, tGrid)
plot (tGrid, yObs, 'k:', label='obs') #  plot (tGrid, expModel(alfa, [1,0], tGrid));  plot (tGrid, expModel(alfa, [0,1], tGrid))
snr=100
yObs *= (1.0 + 1.0/snr*randn(len(tGrid)))
plot (tGrid, yObs, 'ko', label='obs snr %g' % snr)
# separable least squares
alphaInit = np.array([10.0, 1.0])
alfa, beta, yDelta, deltaNorm = varPro (yObs, alphaInit, len(beta), expADA, (tGrid,))
infoVarPro = str('alfa: ' + len(alfa)*' %8.4f' + '   beta: ' + len(beta)*' %8.4f') % tuple(np.concatenate([alfa,beta]))
plot (tGrid, expModel(alfa, beta, tGrid), 'r', label=infoVarPro)
# nonlinear least squares without Jacobian (note that init guess is worse than for varPro!)
xInit = np.concatenate([alphaInit, np.ones_like(beta)])
xVector1, xCovar, infoDict, infoMsg, infoFlag = leastsq (expResidual, xInit, (tGrid, yObs), full_output=1)
infoLeastSq = str('leastsq (fd) %i fct eval ==> xVector: ' + len(xVector1)*' %8.4f') % tuple(np.r_[infoDict['nfev'],xVector1])
plot (tGrid, -expResidual(xVector1, tGrid, np.zeros_like(tGrid)), 'g--', label=infoLeastSq)
# nonlinear least squares with Jacobian (note that init guess is worse than for varPro!)
xVector2, xCovar, infoDict, infoMsg, infoFlag = leastsq (expResidual, xInit, (tGrid, yObs), expJacobian, 1)
infoLeastSq = str('leastsq (ad) %i fct eval ==> xVector: ' + len(xVector2)*' %8.4f') % tuple(np.r_[infoDict['nfev'],xVector2])
plot (tGrid, -expResidual(xVector2, tGrid, np.zeros_like(tGrid)), 'b-.', label=infoLeastSq)
legend()
title(str('aInit: ' + len(alphaInit)*' %8.3f' + '   xInit:' + len(xInit)*' %8.4f') % tuple(np.r_[alphaInit,xInit]))

####################################################################################################################################

def sinResidual (xModel, tGrid, yObs):
	""" Compute the "complete" residual function (observed - model(x))

	    yDelta = yObs - yModel(x) =  sum beta * sin(freq*t+phase)
	"""

	n = len(xModel)
	if n%3:     raise SystemExit ("ERROR --- sinExample:  number of model parameters not a multiple of 3!")
	elif n<3:   raise SystemExit ("ERROR --- sinResidual: incorrect number of model parameters, expected at least one triple")
	else:       amplitudes, freqs, phases = xModel[:n//3], xModel[n//3:2*n//3], xModel[2*n//3:]

	if len(tGrid)!=len(yObs):  raise SystemExit ("ERROR --- sinExample: grid vector and measurement vector have different size!")

	return yObs - sinModel(amplitudes, freqs, phases, tGrid)


def sinJacobian (xModel, tGrid, yObs):
	""" Compute the Jacobian corresponding to the "complete" residual function (observed - model(x)). """

	nSines = len(xModel)//3
	if nSines>0 and len(xModel)-3*nSines==0:
		amplitudes, freqs, phases = xModel[:nSines], xModel[nSines:2*nSines], xModel[2*nSines:]
	else:
		raise SystemExit ("ERROR --- sinJacobian: incorrect number of model parameters, expected one or more triple(s)")
	if len(tGrid)!=len(yObs):
		raise SystemExit ("ERROR --- sinJacobian:  grid vector and measurement vector have different size!")

	jacobian = np.zeros([len(tGrid),3*nSines])
	# derivatives of the model function
	for j,a in enumerate(amplitudes):
		jacobian[:,j]          = np.sin(freqs[j]*tGrid+phases[j])              # d_yModel / d_amplitude
		jacobian[:,j+nSines]   = tGrid * a * np.cos(freqs[j]*tGrid+phases[j])  # d_yModel / d_freq
		jacobian[:,j+2*nSines] =         a * np.cos(freqs[j]*tGrid+phases[j])  # d_yModel / d_phase

	# scale by -1 because of the yObs-yModel
	return -jacobian


def sinModel (amplitudes, freqs, phases, tGrid):
	""" Compute the "complete" model function (sum of sines with phase) as a function of the nonlinear parameters.

	    eta = sum beta * sin(freq*t+phase)
	"""
	if len(amplitudes)==len(freqs)==len(phases):  model = np.zeros_like(tGrid)
	else:                                         raise ValueError("ERROR --- sinModel:  inconsistent array size")

	# accumulate the sines
	for a,f,p in zip(amplitudes, freqs, phases):
		model += a*np.sin(f*tGrid+p)
	return model


def sinADA (alfa, tGrid):
	""" Compute the nonlinear model function(s) (sines with phase) individually. """
	if len(alfa)>=2 and len(alfa)%2==0:
		nSines = len(alfa)//2
		phi        = np.zeros([len(tGrid),   nSines])
		dPhi_dAlfa = np.empty([len(tGrid), 2*nSines])
		index      = np.empty([2, 2*nSines], int)
	else:   raise ValueError("ERROR --- sinExample1:  inconsistent array size (or array too small)")

	freqs, phases = alfa[:nSines], alfa[nSines:]
	for j,f in enumerate(freqs):
		phi[:,j]               =       np.sin(f*tGrid+phases[j])
		dPhi_dAlfa[:,j]        = tGrid*np.cos(f*tGrid+phases[j])
		dPhi_dAlfa[:,j+nSines] =       np.cos(f*tGrid+phases[j])
		index[:,j]             = [j,j]
		index[:,j+nSines]      = [j,j+nSines]

	return phi, dPhi_dAlfa, index


tGrid = linspace(0.0,6.5,33)
#amp, freq, shift = [2.0, 1.0], [1.0, 0.5], [0.1, -0.2]
amp, freq, shift = [2.0, 1.0, 0.5], [1.0, 0.4, 2.5], [0.0, 0.1, -0.2]
yObs = sinModel(amp, freq, shift, tGrid)
plot (tGrid, yObs, 'k:', label='obs') #  plot (tGrid, expModel(alfa, [1,0], tGrid));  plot (tGrid, expModel(alfa, [0,1], tGrid))
snr=100
yObs *= (1.0 + 1.0/snr*randn(len(tGrid)))
plot(tGrid, yObs, 'ko', label='snr=%g' % snr)

# separable least squares
#alphaInit = array([0.7,0.6,0,0])
alphaInit = array([0.9,0.6,1.8, 0,0,0])
alfa, beta, yDelta, deltaNorm = varPro (yObs, alphaInit, len(amp), sinADA, (tGrid,))
infoVarPro = str('varPro %9.3g ===> beta: ' + len(beta)*' %8.4f' + '   alfa: ' + len(alfa)*' %7.3f') % \
             tuple(np.r_[deltaNorm, beta,alfa])
plot (tGrid, sinModel(beta, alfa[:len(alfa)//2], alfa[len(alfa)//2:], tGrid), 'r', label=infoVarPro)

# nonlinear least squares without Jacobian
xInit = np.concatenate([np.ones_like(freq), alphaInit])
xVector1, xCovar, infoDict, infoMsg, infoFlag = leastsq (sinResidual, xInit, (tGrid, yObs), full_output=1)
infoLeastSq = str('leastsq (fd) %i fct eval %9.3g ==> xVector: ' + len(xVector1)*' %7.3f') % \
              tuple(np.r_[infoDict['nfev'],np.linalg.norm(infoDict['fvec']), xVector1])
plot(tGrid, sinModel(beta, alfa[:len(alfa)//2], alfa[len(alfa)//2:], tGrid), 'g-.',  label=infoLeastSq)
xVector2, xCovar, infoDict, infoMsg, infoFlag = leastsq (sinResidual, xInit, (tGrid, yObs), sinJacobian, 1)
infoLeastSq = str('leastsq (fd) %i fct eval %9.3g ==> xVector: ' + len(xVector1)*' %7.3f') % \
              tuple(np.r_[infoDict['nfev'],np.linalg.norm(infoDict['fvec']), xVector2])
plot (tGrid, -sinResidual(xVector2, tGrid, np.zeros_like(tGrid)), 'b-.', label=infoLeastSq)
legend()
title(str('aInit: ' + len(alphaInit)*' %6.2f' + '   xInit:' + len(xInit)*' %6.2f') % tuple(np.r_[alphaInit,xInit]))
suptitle ((len(xVector1)*' %7.2f') % tuple(r_[amp, freq, shift]), fontsize='x-large')

############################################# sin(a+b) = sin(a)*cos(b) + cos(a)*sin(b) #############################################

def sinCosModel (amplitudes, freqs, tGrid):
	""" Compute the "complete" model function (sum of sines and cosines) as a function of the nonlinear parameters. """
	nFreqs = len(freqs)
	if len(amplitudes)==2*nFreqs:  model = np.zeros_like(tGrid)
	else:                          raise ValueError("ERROR --- sinExample2:  inconsistent array size")
	ampSin, ampCos = alfa[:nFreqs], alfa[nFreqs:]
	for j,f in enumerate(freqs):
		model += ampSin[j]*np.sin(f*tGrid) + ampCos[j]*np.cos(f*tGrid)
	return model

def sinCosADA (alfa, tGrid):
	""" Compute the nonlinear model function(s) (sines and cosines without phase) individually. """
	if len(alfa)>=2 and len(alfa)%2==0:
		nSines = len(alfa)/2
		phi        = np.zeros([len(tGrid), nSines])
		dPhi_dAlfa = np.empty([len(tGrid), nSines])
		index      = np.empty([2, 2*nSines])
	else:   raise ValueError("ERROR --- sinExample1:  inconsistent array size (or array too small)")

	freqs, phases = alfa[:nSines], alfa[nSines:]
	for j,f in enumerate(freqs):
		phi[:,j]               =       np.sin(f*tGrid+phases[j])
		dPhi_dAlfa[:,j]        = tGrid*np.cos(f*tGrid+phases[j])
		dPhi_dAlfa[:,j+nSines] =       np.cos(f*tGrid+phases[j])
		index[:,j]             = [j,j]
		index[:,j+nSines]      = [j,j+nSines]

	return phi, dPhi_dAlfa, index
