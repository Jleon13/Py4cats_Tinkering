""" Modules for MT-CKD H2O self and foreign continua (version 4, as provided by HITRAN). """

####################################################################################################################################
##########     LICENSE issues:                                                                                            ##########
##########                       This file is part of the Py4CAtS package.                                                ##########
##########                       Copyright 2002 - 2023; Franz Schreier;  DLR-IMF Oberpfaffenhofen                         ##########
##########                       Py4CAtS is distributed under the terms of the GNU General Public License;                ##########
##########                       see the file ../license.txt in the parent directory.                                     ##########
####################################################################################################################################

try:   import numpy as np
except ImportError as msg:  raise SystemExit(str(msg) + '\nimport numeric python failed!')

from py4cats.var.ir import c, h, k  # speed of light, Planck and Boltzmann constant
from py4cats.var.cgsUnits import cgs
from py4cats.var.pairTypes import Interval
from py4cats.art.oDepth import odArray

pRef, tRef = cgs('mb',1013.25), 296.0
refDensity = pRef/(k*tRef)

####################################################################################################################################

def add_mtckd2od (optDepth, mtckdFile, verbose=False):
	"""
	Add MT-CKD Mlawer-Tobin-Clough-Kneizys-Davies H2O self and foreign continua (version 4) to molecular optical depth.

	ARGUMENTS:
	optDepth    (list of) optical depth(s) (either a single odArray or a list thereof)
	mtckdFile   tabular (ascii) file of continua data with four columns (a copy of the netcdf file)
	            wavenumber, foreign continuum, self continuum, temperature exponent
	"""

	# check input optical depth(s), wavenumbers
	if isinstance(optDepth, (list,tuple)):
		# check consistency of wavenumber intervals
		vLimits = optDepth[0].x
		if not all([optDepth[0].x==od.x for od in optDepth[1:]]):
			raise ValueError ("mtckd:  list of optical depths with inconsistent wavenumbers!")
	elif isinstance(optDepth, odArray):
		vLimits  = optDepth.x
		optDepth = [optDepth]
	else:
		raise ValueError ("add_mtckd2od:  neither a single optical depth (odArray) nor a list thereof")

	# read Hitran MT-CKD4 data
	vGrid, xsf, xss, sExp = np.loadtxt(mtckdFile, unpack=1)
	if not vLimits.part(Interval(vGrid[0],vGrid[-1])):
		raise ValueError ("mtckd:  optical depth(s) wavenumber interval not fully inside MTCKD interval")

	# loop thru atmosphere
	dodList = []
	for l,od in enumerate(optDepth):
		if verbose:  print ('%3.3i  %s %s' % (l, od.info(), ' --->'))
		if isinstance(od.N, dict):
			if 'H2O' not in od.N:  raise ValueError ("add_mtckd2od:  no H2O contributing to optical depth")
		else:
			raise ValueError ("add_mtckd2od:  no individual molecular column densities in optical depth attribute")
		# adjust to actual density and temperature
		tMean   = np.mean(od.t.list())
		tFactor = (tRef/tMean)**sExp
		ckdOD   = od.N['H2O']*((od.N['air']-od.N['H2O'])*xsf + od.N['H2O']*tFactor*xss) /(abs(od.z.delta())*refDensity)
		# scale with radiation term, interpolate to monochromatic grid, and add to lbl absorption coefficient
		odx   = od.base + np.interp(od.grid(), vGrid, vGrid*np.tanh(h*c*vGrid/(k*tMean))*ckdOD)
		dodList.append(odArray(odx, od.x, od.z, od.p, od.t, od.N))
		if verbose:  print ("    ", od.info())

	# test not yet perfect, on entry there could be a list with just one element!
	if len(dodList)>1:  return dodList
	else:               return dodList[0]
