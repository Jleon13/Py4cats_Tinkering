""" Modules for Collision Induced Absorption (and CKD continua?) """

####################################################################################################################################
##########     LICENSE issues:                                                                                            ##########
##########                       This file is part of the Py4CAtS package.                                                ##########
##########                       Copyright 2002 - 2021; Franz Schreier;  DLR-IMF Oberpfaffenhofen                         ##########
##########                       Py4CAtS is distributed under the terms of the GNU General Public License;                ##########
##########                       see the file ../license.txt in the parent directory.                                     ##########
####################################################################################################################################

import os
from glob import glob

try:   import numpy as np
except ImportError as msg:  raise SystemExit(str(msg) + '\nimport numeric python failed!')

# prepare plotting
try:                 from matplotlib.pyplot import semilogy, legend, xlabel, ylabel
except ImportError:  print ('WARNING --- xSection:  matplotlib not available, no quicklook!')
else:                pass  # print 'matplotlib imported and setup'

from py4cats.var.aeiou import grep
from py4cats.var.euGrid import is_uniform
from py4cats.var.pairTypes import Interval
from py4cats.art.absCo import acArray
from py4cats.art.oDepth import odArray


####################################################################################################################################

def read_hitran_cia (ciaFile, xLimits=None, xsMin=0.0, verbose=False):
	""" Read a Hitran CIA cross section file, pack "spectrum" into a dictionary, and return a list of data.
	    Optionally truncate w.r.t. wavenumbers and/or small (default: negative) values.
	"""

	if not os.path.isfile(ciaFile):
		raise ValueError ('cia.read_hitran_cia failed, file "%s" does not exist' % ciaFile)
	if isinstance(xLimits,(tuple,list)):  xLimits=Interval(*xLimits)
	comments = grep(ciaFile, '^ *[A-Z]')
	data     = np.loadtxt(ciaFile, usecols=(0,1), comments=comments[0][0])  # some files have 3 columns occasionally
	xsList = []
	iLow = 0
	for block in comments:
		header = block.split()
		pair   = header[0].split('-')
		if pair[1]=='Air':  pair[1]='air'   # use lower case because py4cats atmos1D structure array is lower case
		vMin, vMax, nData, temp   = float(header[1]), float(header[2]), int(header[3]), float(header[4])
		vGrid, xsValues = data[iLow:iLow+nData,0], data[iLow:iLow+nData,1]
		mask = xsValues>xsMin
		if isinstance(xLimits, Interval):  mask = np.logical_and (xLimits.member(vGrid), mask)
		if verbose and not is_uniform(vGrid):  print('WARNING - read_hitran_cia:  wavenumber grid is not uniform!')
		if sum(mask)>0:
			xsList.append({'pair': pair, 'vMin': vMin,  'vMax': vMax, 'temperature': temp,
		                       'vGrid': vGrid[mask], 'yData': xsValues[mask]})
			if verbose:  print (ciaFile, pair, temp, vMin, vMax, min(xsValues[mask]), max(xsValues[mask]))
		else:
			if verbose:  print ("WARNING --- read_hitran_cia:  CIA in %s for %f -- %f ignored" %
			                    (os.path.split(ciaFile)[1], vMin, vMax))
		iLow += nData
	return xsList


####################################################################################################################################

def ciaInfo (xsData):
	""" Print information on CIA cross section(s). """
	if isinstance(xsData,(list,tuple)):
		print ("\n Collision induced absorption data:", len(xsData), "cross sections:")
		for xs in xsData:  ciaInfo(xs)
	elif isinstance(xsData, dict):
		print (' %s-%s' % tuple(xsData['pair']),
		       '%9.1fK  %9.2f - %6.2fcm-1   %10g - %10g' %
		       (xsData['temperature'], xsData['vMin'], xsData['vMax'], min(xsData['yData']), max(xsData['yData'])))
	else:
		raise ValueError ("cia:  invalid data type for ciaPlot, expected a single cross section or a dictionary thereof")


####################################################################################################################################

def ciaPlot (xsData, **kwArgs):
	""" Plot CIA cross section(s) vs. wavenumbers. """
	if isinstance(xsData,(list,tuple)):
		for xs in xsData:  ciaPlot(xs)
	elif isinstance(xsData, dict):
		if 'label' in kwArgs:  labelText=kwArgs.pop('label')
		else:                  labelText='%s-%s %.1fK' % (xsData['pair'][0], xsData['pair'][1], xsData['temperature'])
		semilogy (xsData['vGrid'], xsData['yData'], label=labelText, **kwArgs)
	else:
		raise ValueError ("cia:  invalid data type for ciaPlot, expected a single cross section or a dictionary thereof")
	legend()
	xlabel(r"Wavenumber $\nu$ [cm$^{-1}$]")
	ylabel("CIA cross section")


####################################################################################################################################

def add_cia2absCo (absCo, ciaData, xsMin=0.0, verbose=False):
	"""
	Add collision induced absorption 'cross section(s)' to molecular (line-by-line) absorption coefficient(s).

	ARGUMENTS:
	absCo     absorption coefficient(s), either a single acArray or a list thereof
	ciaData   collision induced absorption data, either a single file or a list thereof (* wildcard supported!)
	xsMin     minimum value of cia data to accept, default 0.0 (i.e. ignore negative values)

	RETURN:
	absCo     absorption coefficient(s) with CIA added
	"""

	# a single CIA file or a list?
	if isinstance(ciaData, str):
		if os.path.isfile(ciaData):
			pass
		else:
			if   '*' in ciaData or '?' in ciaData:
				ciaFiles = glob(ciaData)
			elif ' ' in ciaData:
				ciaFiles = ciaData.split()
			elif os.path.isdir(ciaData):
				ciaFiles = [file for file in os.listdir(ciaData) if os.path.isfile(file)]
			else:   raise ValueError ('add_cia2absCo --- CIA file(s) given unreasonable!')
			for cf in ciaFiles:
				print ("add_cia2absCo: ", cf)
				absCo = add_cia2absCo (absCo, cf, xsMin, verbose)  # call recursively
			return absCo
	elif isinstance(ciaData, (list, tuple)):
		for cf in ciaData:
			absCo = add_cia2absCo (absCo, cf, xsMin, verbose)  # call recursively
		return absCo
	else:
		raise ValueError ("cia:  ciaData neither a single file nor a list thereof")

	# check input absorption coefficient(s), wavenumbers
	if isinstance(absCo, (list,tuple)):
		# check consistency of wavenumber intervals
		vLimits = absCo[0].x
		if not all([absCo[0].x==ac.x for ac in absCo[1:]]):
			raise ValueError ("cia:  list of absorption coefficients with inconsistent wavenumbers!")
	elif isinstance(absCo, acArray):
		vLimits = absCo.x
		absCo = [absCo]
	else:
		raise ValueError ("add_cia2absCo:  neither a single absorption coefficient (acArray) nor a list thereof")

	# read all CIA cross sections
	cxsList   = read_hitran_cia(ciaData, vLimits, xsMin, verbose)
	if cxsList:
		cxsTemp = [cxs['temperature'] for cxs in cxsList]
		print ("INFO --- add_cia2ac:  %i cross sections found in %s with %.1f <T< %1.fK" %
		       (len(cxsList), ciaData, min(cxsTemp), max(cxsTemp)))
	else:
		cFile = os.path.split(ciaData)[1]
		print ("WARNING --- add_cia2abs:  no cia cross sections in %s for wavenumber %s" % (cFile, vLimits))
		return absCo

	# loop thru atmosphere
	acList = []
	for l,ac in enumerate(absCo):
		if verbose:  print (ac.info())
		# locate the next/best CIA cross sections w.r.t. temperature
		nxt = np.argmin(np.array([abs(cxs['temperature']-ac.t) for cxs in cxsList]))
		thisMolec, otherMolec = cxsList[nxt]['pair']
		# special cases
		if thisMolec=='N2' and otherMolec=='N2' and 'N2' not in ac.molec.keys():  # Assume Earth!
			ciaAC = (0.78*ac.molec['air'])**2 * cxsList[nxt]['yData']
		elif thisMolec=='N2' and 'N2' not in ac.molec.keys():  # Assume Earth!
			ciaAC = 0.78*ac.molec['air']*ac.molec[otherMolec] * cxsList[nxt]['yData']
		elif otherMolec=='N2' and 'N2' not in ac.molec.keys():  # Assume Earth!
			ciaAC = 0.78*ac.molec['air']*ac.molec[thisMolec] * cxsList[nxt]['yData']
		else:
			ciaAC = ac.molec[thisMolec]*ac.molec[otherMolec] * cxsList[nxt]['yData']
		# interpolate to monochromatic grid and add to lbl absorption coefficient
		acx   = ac.base + np.interp(ac.grid(), cxsList[nxt]['vGrid'], ciaAC)
		acList.append(acArray(acx, ac.x, ac.z, ac.p, ac.t, ac.molec))
		if verbose:
			print ('adding cia #%i %.1fK ===> %125s\n' % (nxt,  cxsList[nxt]['temperature'], acList[-1].info()[125:]))

	# test not yet perfect, on entry there could be a list with just one element!
	if len(acList)>1:  return acList
	else:              return acList[0]


####################################################################################################################################

def add_cia (absData, ciaData, xsMin=0.0, verbose=False):
	"""
	Add collision induced absorption 'cross section(s)' to molecular absorption coefficient(s) or optical depth(s).

	ARGUMENTS:
	absData   absorption coefficient(s) or optical depth(s), either a single acArray/odArray or a list thereof
	ciaData   collision induced absorption data, either a single file or a list thereof (* wildcard supported!)
	xsMin     minimum value of cia data to accept, default 0.0 (i.e. ignore negative values)
	"""

	# a single CIA file or a list?
	if isinstance(ciaData, str):
		if not os.path.isfile(ciaData):
			if   '*' in ciaData or '?' in ciaData: ciaFiles = glob(ciaData)
			elif ' ' in ciaData:                   ciaFiles = ciaData.split()
			elif os.path.isdir(ciaData):           ciaFiles = [file for file in os.listdir(ciaData) if os.path.isfile(file)]
			else:                                  raise ValueError ('add_cia --- CIA file(s) given unreasonable!')
			for cf in ciaFiles:  absData = add_cia (absData, cf, xsMin, verbose)  # call recursively
			return absData
	elif isinstance(ciaData, (list, tuple)):
		for cf in ciaData:
			absData = add_cia (absData, cf, xsMin, verbose)  # call recursively
		return absData
	else:
		raise ValueError ("cia:  ciaData neither a single file nor a list thereof")

	# check input absorption coefficient(s), wavenumbers
	if isinstance(absData, (list,tuple)):
		# check consistency of wavenumber intervals
		vLimits = absData[0].x
		if not all([absData[0].x==acod.x for acod in absData[1:]]):
			raise ValueError ("cia:  list of absorption coefficients / optical depths with inconsistent wavenumbers!")
	elif isinstance(absData, (acArray, odArray)):
		vLimits = absData.x
		absData = [absData]
	else:
		raise ValueError ("add_cia2absCo:  neither a single acArray or odArray nor a list thereof")

	# read all CIA cross sections
	cxsList   = read_hitran_cia(ciaData, vLimits, xsMin, verbose)
	if cxsList:
		cxsTemp = np.array([cxs['temperature'] for cxs in cxsList])
		print ("INFO --- add_cia:  %i cross sections found in %s with %.1f <T< %1.fK" %
		       (len(cxsList), ciaData, min(cxsTemp), max(cxsTemp)))
	else:
		cFile = os.path.split(ciaData)[1]
		print ("WARNING --- add_cia:  no cia cross sections in %s for wavenumber %s" % (cFile, vLimits))
		return absData

	# loop thru atmosphere
	absList = []
	if all([isinstance(ac, acArray) for ac in absData]):
		for l,ac in enumerate(absData):
			if verbose:  print(ac.info())
			# locate the next/best CIA cross sections w.r.t. temperature
			nxt = np.argmin(abs(cxsTemp-ac.t))
			thisMolec, otherMolec = cxsList[nxt]['pair']
			# special cases for N2 or O2 with air:  Assume Earth!
			if thisMolec=='N2' and otherMolec=='air' and 'N2' not in ac.molec.keys():
				ciaAC = 0.781*ac.molec['air']**2 * cxsList[nxt]['yData']
			elif thisMolec=='O2' and otherMolec=='air' and 'O2' not in ac.molec.keys():
				ciaAC = 0.209*ac.molec['air']**2 * cxsList[nxt]['yData']
			elif ((thisMolec=='O2' and otherMolec=='N2') or (thisMolec=='N2' and otherMolec=='O2')) and \
			      'O2' not in ac.N.keys() and 'N2' not in ac.N.keys():
				ciaAC = 0.781*0.209*ac.molec['air']**2 * cxsList[nxt]['yData']
			else:
				ciaAC = ac.molec[thisMolec]*ac.molec[otherMolec] * cxsList[nxt]['yData']
			# interpolate to monochromatic grid and add to lbl absorption coefficient
			acx   = ac.base + np.interp(ac.grid(), cxsList[nxt]['vGrid'], ciaAC)
			absList.append(acArray(acx, ac.x, ac.z, ac.p, ac.t, ac.molec))
			if verbose:  print ('adding cia #%i %.1fK ===> %125s\n' %
			                    (nxt,  cxsList[nxt]['temperature'], absList[-1].info()[125:]))
	elif all([isinstance(od, odArray) for od in absData]):
		for l,od in enumerate(absData):
			if verbose:  print(od.info())
			deltaZ = abs(od.z.delta())
			# locate the next/best CIA cross sections w.r.t. temperature
			nxt = np.argmin(abs(cxsTemp-od.t.mean()))
			thisMolec, otherMolec = cxsList[nxt]['pair']
			# special cases for N2 or O2 with air:  assume Earth!
			if thisMolec=='N2' and otherMolec=='air' and 'N2' not in od.N.keys():
				airDensity = od.N['air']/deltaZ
				ciaAC = 0.781*airDensity**2 * cxsList[nxt]['yData']
			elif thisMolec=='O2' and otherMolec=='air' and 'O2' not in od.N.keys():
				airDensity = od.N['air']/deltaZ
				ciaAC = 0.209*airDensity**2 * cxsList[nxt]['yData']
			elif 'O2' in cxsList[nxt]['pair'] and 'N2' in cxsList[nxt]['pair'] and \
			     'O2' not in od.N.keys() and 'N2' not in od.N.keys():
				airDensity = od.N['air']/deltaZ
				ciaAC = 0.781*0.209*airDensity**2 * cxsList[nxt]['yData']
			else:
				thisDensity, otherDensity = od.N[thisMolec]/deltaZ, od.N[otherMolec]/deltaZ
				ciaAC = thisDensity*otherDensity * cxsList[nxt]['yData']
			# multiply cia-abs.co with path length, interpolate to monochromatic grid and add to optical depth
			odx   = od.base + np.interp(od.grid(), cxsList[nxt]['vGrid'], deltaZ*ciaAC)
			absList.append(odArray(odx, od.x, od.z, od.p, od.t, od.N))
			if verbose:  print ('adding cia #%i %.1fK ===> %145s\n' %
			                    (nxt,  cxsList[nxt]['temperature'], absList[-1].info()[144:]))
	else:
		raise TypeError ("add_cia:  neither a list of acArray's nor a list of odArray's")

	# test not yet perfect, on entry there could be a list with just one element!
	if len(absList)>1:  return absList
	else:               return absList[0]
